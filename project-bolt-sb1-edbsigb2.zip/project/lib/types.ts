// User roles
export type UserRole = 'admin' | 'sales_manager' | 'sales_executive';

// Institution types
export type InstitutionType = 'college' | 'university' | 'polytechnic' | 'institute';

// Lead status flow
export type LeadStatus = 'new_lead' | 'contacted' | 'meeting_scheduled' | 'proposal_sent' | 'negotiation' | 'closed_won' | 'closed_lost';

// Potential rating
export type PotentialRating = 'low' | 'medium' | 'high' | 'very_high';

// Activity types
export type ActivityType = 'call' | 'email' | 'meeting' | 'note' | 'status_change' | 'document_upload' | 'follow_up' | 'ai_insight';

// Meeting types
export type MeetingType = 'virtual' | 'in_person' | 'phone';

// Meeting status
export type MeetingStatus = 'scheduled' | 'completed' | 'cancelled' | 'rescheduled';

// Email types
export type EmailType = 'introduction' | 'proposal_followup' | 'meeting_reminder' | 'partnership_proposal' | 'custom';

// Email status
export type EmailStatus = 'draft' | 'sent' | 'delivered' | 'opened' | 'replied';

// Follow-up priority
export type FollowUpPriority = 'low' | 'medium' | 'high';

// Follow-up status
export type FollowUpStatus = 'pending' | 'completed' | 'missed';

// User Profile
export interface Profile {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  avatar_url?: string;
  created_at: string;
  updated_at: string;
}

// Institution/Lead
export interface Institution {
  id: string;
  institution_name: string;
  institution_type: InstitutionType;
  city: string;
  state: string;
  contact_person: string;
  designation?: string;
  email: string;
  phone: string;
  student_strength?: number;
  program_interest?: string;
  lead_source?: string;
  assigned_to?: string;
  notes?: string;
  last_contact_date?: string;
  next_followup_date?: string;
  lead_status: LeadStatus;
  priority_score?: number;
  potential_rating?: PotentialRating;
  partnership_probability?: number;
  recommended_action?: string;
  ai_insights?: string;
  created_at: string;
  updated_at: string;
  assigned_user?: Profile;
}

// Activity
export interface Activity {
  id: string;
  institution_id: string;
  user_id: string;
  activity_type: ActivityType;
  title: string;
  description?: string;
  metadata?: Record<string, any>;
  created_at: string;
  user?: Profile;
}

// Meeting
export interface Meeting {
  id: string;
  institution_id: string;
  user_id: string;
  title: string;
  description?: string;
  meeting_date: string;
  duration_minutes: number;
  meeting_type: MeetingType;
  location?: string;
  status: MeetingStatus;
  outcome?: string;
  notes?: string;
  reminder_sent: boolean;
  created_at: string;
  updated_at: string;
  institution?: Institution;
  user?: Profile;
}

// Email
export interface Email {
  id: string;
  institution_id: string;
  user_id: string;
  subject: string;
  body: string;
  email_type: EmailType;
  status: EmailStatus;
  sent_at: string;
  created_at: string;
  institution?: Institution;
  user?: Profile;
}

// Document
export interface Document {
  id: string;
  institution_id: string;
  user_id: string;
  name: string;
  file_url: string;
  file_type?: string;
  file_size?: number;
  created_at: string;
  user?: Profile;
}

// Follow-up Task
export interface FollowUp {
  id: string;
  institution_id: string;
  user_id: string;
  title: string;
  description?: string;
  due_date: string;
  status: FollowUpStatus;
  priority: FollowUpPriority;
  completed_at?: string;
  created_at: string;
  institution?: Institution;
  user?: Profile;
}

// Dashboard Stats
export interface DashboardStats {
  total_institutions: number;
  new_leads: number;
  active_leads: number;
  meetings_scheduled: number;
  proposals_sent: number;
  closed_deals: number;
  conversion_rate: number;
  revenue_pipeline: number;
}
