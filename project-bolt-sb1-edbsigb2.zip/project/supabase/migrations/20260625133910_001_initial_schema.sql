-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- User profiles table (extends Supabase auth)
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'sales_executive' CHECK (role IN ('admin', 'sales_manager', 'sales_executive')),
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Institutions/Leads table
CREATE TABLE institutions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_name TEXT NOT NULL,
  institution_type TEXT NOT NULL CHECK (institution_type IN ('college', 'university', 'polytechnic', 'institute')),
  city TEXT NOT NULL,
  state TEXT NOT NULL,
  contact_person TEXT NOT NULL,
  designation TEXT,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  student_strength INTEGER,
  program_interest TEXT,
  lead_source TEXT,
  assigned_to UUID REFERENCES profiles(id),
  notes TEXT,
  last_contact_date DATE,
  next_followup_date DATE,
  lead_status TEXT NOT NULL DEFAULT 'new_lead' CHECK (lead_status IN ('new_lead', 'contacted', 'meeting_scheduled', 'proposal_sent', 'negotiation', 'closed_won', 'closed_lost')),
  
  -- AI generated fields
  priority_score INTEGER CHECK (priority_score >= 0 AND priority_score <= 100),
  potential_rating TEXT CHECK (potential_rating IN ('low', 'medium', 'high', 'very_high')),
  partnership_probability DECIMAL(5,2),
  recommended_action TEXT,
  ai_insights TEXT,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Activities/Activity Log
CREATE TABLE activities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id UUID REFERENCES institutions(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id),
  activity_type TEXT NOT NULL CHECK (activity_type IN ('call', 'email', 'meeting', 'note', 'status_change', 'document_upload', 'follow_up', 'ai_insight')),
  title TEXT NOT NULL,
  description TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Meetings
CREATE TABLE meetings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id UUID REFERENCES institutions(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id),
  title TEXT NOT NULL,
  description TEXT,
  meeting_date TIMESTAMPTZ NOT NULL,
  duration_minutes INTEGER DEFAULT 60,
  meeting_type TEXT DEFAULT 'virtual' CHECK (meeting_type IN ('virtual', 'in_person', 'phone')),
  location TEXT,
  status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed', 'cancelled', 'rescheduled')),
  outcome TEXT,
  notes TEXT,
  reminder_sent BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Emails/Communications
CREATE TABLE emails (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id UUID REFERENCES institutions(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id),
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  email_type TEXT DEFAULT 'custom' CHECK (email_type IN ('introduction', 'proposal_followup', 'meeting_reminder', 'partnership_proposal', 'custom')),
  status TEXT DEFAULT 'sent' CHECK (status IN ('draft', 'sent', 'delivered', 'opened', 'replied')),
  sent_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Documents
CREATE TABLE documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id UUID REFERENCES institutions(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id),
  name TEXT NOT NULL,
  file_url TEXT NOT NULL,
  file_type TEXT,
  file_size INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Follow-up Tasks
CREATE TABLE follow_ups (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  institution_id UUID REFERENCES institutions(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id),
  title TEXT NOT NULL,
  description TEXT,
  due_date TIMESTAMPTZ NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'missed')),
  priority TEXT DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE institutions ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE meetings ENABLE ROW LEVEL SECURITY;
ALTER TABLE emails ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE follow_ups ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "profiles_select_own" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_insert_own" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_all_admin" ON profiles FOR ALL
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- RLS Policies for institutions
CREATE POLICY "institutions_select_all" ON institutions FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "institutions_insert_all" ON institutions FOR INSERT
  TO authenticated WITH CHECK (true);
CREATE POLICY "institutions_update_assigned" ON institutions FOR UPDATE
  TO authenticated USING (
    assigned_to = auth.uid() OR 
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'sales_manager'))
  ) WITH CHECK (
    assigned_to = auth.uid() OR 
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'sales_manager'))
  );
CREATE POLICY "institutions_delete_admin" ON institutions FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- RLS Policies for activities
CREATE POLICY "activities_select_all" ON activities FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "activities_insert_own" ON activities FOR INSERT
  TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "activities_delete_own" ON activities FOR DELETE
  TO authenticated USING (user_id = auth.uid());

-- RLS Policies for meetings
CREATE POLICY "meetings_select_all" ON meetings FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "meetings_insert_own" ON meetings FOR INSERT
  TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "meetings_update_own" ON meetings FOR UPDATE
  TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "meetings_delete_own" ON meetings FOR DELETE
  TO authenticated USING (user_id = auth.uid());

-- RLS Policies for emails
CREATE POLICY "emails_select_all" ON emails FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "emails_insert_own" ON emails FOR INSERT
  TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "emails_delete_own" ON emails FOR DELETE
  TO authenticated USING (user_id = auth.uid());

-- RLS Policies for documents
CREATE POLICY "documents_select_all" ON documents FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "documents_insert_own" ON documents FOR INSERT
  TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "documents_delete_own" ON documents FOR DELETE
  TO authenticated USING (user_id = auth.uid());

-- RLS Policies for follow_ups
CREATE POLICY "follow_ups_select_all" ON follow_ups FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "follow_ups_insert_own" ON follow_ups FOR INSERT
  TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "follow_ups_update_own" ON follow_ups FOR UPDATE
  TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "follow_ups_delete_own" ON follow_ups FOR DELETE
  TO authenticated USING (user_id = auth.uid());

-- Create indexes for better performance
CREATE INDEX idx_institutions_status ON institutions(lead_status);
CREATE INDEX idx_institutions_assigned ON institutions(assigned_to);
CREATE INDEX idx_institutions_state ON institutions(state);
CREATE INDEX idx_meetings_date ON meetings(meeting_date);
CREATE INDEX idx_follow_ups_due ON follow_ups(due_date);
CREATE INDEX idx_activities_institution ON activities(institution_id);

-- Function to update timestamps
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_institutions_updated_at
  BEFORE UPDATE ON institutions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_meetings_updated_at
  BEFORE UPDATE ON meetings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();