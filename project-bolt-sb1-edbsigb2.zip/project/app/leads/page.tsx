'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/auth-context';
import { Institution, Profile, LeadStatus, InstitutionType } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Eye,
  Mail,
  Phone,
  Building2,
  MapPin,
  Calendar,
  Sparkles,
  Filter,
  Download,
  Upload,
  FileText,
  Users,
  GraduationCap,
  X,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { format } from 'date-fns';

const STATUS_OPTIONS: { value: LeadStatus; label: string; color: string }[] = [
  { value: 'new_lead', label: 'New Lead', color: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300' },
  { value: 'contacted', label: 'Contacted', color: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900 dark:text-cyan-300' },
  { value: 'meeting_scheduled', label: 'Meeting Scheduled', color: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300' },
  { value: 'proposal_sent', label: 'Proposal Sent', color: 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300' },
  { value: 'negotiation', label: 'Negotiation', color: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300' },
  { value: 'closed_won', label: 'Closed Won', color: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300' },
  { value: 'closed_lost', label: 'Closed Lost', color: 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300' },
];

const INSTITUTION_TYPES: { value: InstitutionType; label: string }[] = [
  { value: 'college', label: 'College' },
  { value: 'university', label: 'University' },
  { value: 'polytechnic', label: 'Polytechnic' },
  { value: 'institute', label: 'Institute' },
];

const LEAD_SOURCES = [
  'Website',
  'Referral',
  'Event',
  'Campaign',
  'LinkedIn',
  'Direct',
  'Partner',
  'Other',
];

const PROGRAM_INTERESTS = [
  'Workshop',
  'Internship',
  'Certification Program',
  'Technical Training',
  'Industry Collaboration',
  'Faculty Development',
  'Placement Training',
  'Custom Program',
];

const STATES = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
  'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand',
  'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur',
  'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab',
  'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura',
  'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Delhi',
];

interface LeadFormData {
  institution_name: string;
  institution_type: InstitutionType;
  city: string;
  state: string;
  contact_person: string;
  designation: string;
  email: string;
  phone: string;
  student_strength: number;
  program_interest: string;
  lead_source: string;
  notes: string;
  next_followup_date: string;
}

const initialFormData: LeadFormData = {
  institution_name: '',
  institution_type: 'college',
  city: '',
  state: '',
  contact_person: '',
  designation: '',
  email: '',
  phone: '',
  student_strength: 0,
  program_interest: '',
  lead_source: '',
  notes: '',
  next_followup_date: '',
};

export default function LeadsPage() {
  const { profile, isManager } = useAuth();
  const { toast } = useToast();

  const [leads, setLeads] = useState<Institution[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [stateFilter, setStateFilter] = useState<string>('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [aiDialogOpen, setAiDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedLead, setSelectedLead] = useState<Institution | null>(null);
  const [formData, setFormData] = useState<LeadFormData>(initialFormData);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [aiInsights, setAiInsights] = useState<any>(null);
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    loadLeads();
    loadUsers();
  }, [profile]);

  const loadLeads = async () => {
    if (!profile) return;

    try {
      setLoading(true);
      let query = supabase
        .from('institutions')
        .select('*, assigned_user:profiles!assigned_to(*)')
        .order('created_at', { ascending: false });

      if (!isManager) {
        query = query.eq('assigned_to', profile.id);
      }

      const { data, error } = await query;

      if (error) throw error;
      setLeads(data || []);
    } catch (error) {
      console.error('Error loading leads:', error);
      toast({
        title: 'Error',
        description: 'Failed to load leads',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const loadUsers = async () => {
    try {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .order('full_name');
      setUsers(data || []);
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };

  const filteredLeads = leads.filter((lead) => {
    const matchesSearch =
      lead.institution_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lead.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lead.contact_person.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lead.email.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'all' || lead.lead_status === statusFilter;
    const matchesState = stateFilter === 'all' || lead.state === stateFilter;

    return matchesSearch && matchesStatus && matchesState;
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    try {
      const leadData = {
        ...formData,
        assigned_to: profile.id,
        student_strength: Number(formData.student_strength) || 0,
      };

      if (editingId) {
        const { error } = await supabase
          .from('institutions')
          .update(leadData)
          .eq('id', editingId);

        if (error) throw error;

        toast({
          title: 'Success',
          description: 'Lead updated successfully',
        });
      } else {
        const { error } = await supabase
          .from('institutions')
          .insert([leadData]);

        if (error) throw error;

        toast({
          title: 'Success',
          description: 'Lead created successfully',
        });
      }

      setDialogOpen(false);
      setFormData(initialFormData);
      setEditingId(null);
      loadLeads();
    } catch (error) {
      console.error('Error saving lead:', error);
      toast({
        title: 'Error',
        description: 'Failed to save lead',
        variant: 'destructive',
      });
    }
  };

  const handleEdit = (lead: Institution) => {
    setFormData({
      institution_name: lead.institution_name,
      institution_type: lead.institution_type,
      city: lead.city,
      state: lead.state,
      contact_person: lead.contact_person,
      designation: lead.designation || '',
      email: lead.email,
      phone: lead.phone,
      student_strength: lead.student_strength || 0,
      program_interest: lead.program_interest || '',
      lead_source: lead.lead_source || '',
      notes: lead.notes || '',
      next_followup_date: lead.next_followup_date || '',
    });
    setEditingId(lead.id);
    setDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!selectedLead) return;

    try {
      const { error } = await supabase
        .from('institutions')
        .delete()
        .eq('id', selectedLead.id);

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Lead deleted successfully',
      });

      setDeleteDialogOpen(false);
      setSelectedLead(null);
      loadLeads();
    } catch (error) {
      console.error('Error deleting lead:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete lead',
        variant: 'destructive',
      });
    }
  };

  const handleStatusChange = async (leadId: string, newStatus: LeadStatus) => {
    try {
      const { error } = await supabase
        .from('institutions')
        .update({ lead_status: newStatus })
        .eq('id', leadId);

      if (error) throw error;

      // Log activity
      await supabase.from('activities').insert([{
        institution_id: leadId,
        user_id: profile?.id,
        activity_type: 'status_change',
        title: `Status changed to ${STATUS_OPTIONS.find(s => s.value === newStatus)?.label}`,
        metadata: { old_status: leads.find(l => l.id === leadId)?.lead_status, new_status: newStatus },
      }]);

      toast({
        title: 'Success',
        description: 'Status updated successfully',
      });

      loadLeads();
    } catch (error) {
      console.error('Error updating status:', error);
      toast({
        title: 'Error',
        description: 'Failed to update status',
        variant: 'destructive',
      });
    }
  };

  const generateAIInsights = async (lead: Institution) => {
    setAiLoading(true);
    setAiDialogOpen(true);
    setSelectedLead(lead);

    try {
      const response = await fetch('/api/ai/analyze-lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lead }),
      });

      const data = await response.json();
      setAiInsights(data);

      // Update lead with AI insights
      if (data.priorityScore !== undefined) {
        await supabase
          .from('institutions')
          .update({
            priority_score: data.priorityScore,
            potential_rating: data.potentialRating,
            partnership_probability: data.partnershipProbability,
            recommended_action: data.recommendedAction,
            ai_insights: data.insights,
          })
          .eq('id', lead.id);

        loadLeads();
      }
    } catch (error) {
      console.error('Error generating AI insights:', error);
      toast({
        title: 'Error',
        description: 'Failed to generate AI insights',
        variant: 'destructive',
      });
    } finally {
      setAiLoading(false);
    }
  };

  const getStatusColor = (status: LeadStatus) => {
    return STATUS_OPTIONS.find((s) => s.value === status)?.color || '';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Institution Leads</h2>
          <p className="text-muted-foreground">Manage your educational institution relationships</p>
        </div>
        <Button onClick={() => { setFormData(initialFormData); setEditingId(null); setDialogOpen(true); }}>
          <Plus className="mr-2 h-4 w-4" />
          Add New Lead
        </Button>
      </div>

      {/* Filters */}
      <Card className="glass-card">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name, city, contact..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-[180px]">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                {STATUS_OPTIONS.map((status) => (
                  <SelectItem key={status.value} value={status.value}>
                    {status.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={stateFilter} onValueChange={setStateFilter}>
              <SelectTrigger className="w-full md:w-[180px]">
                <MapPin className="mr-2 h-4 w-4" />
                <SelectValue placeholder="State" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All States</SelectItem>
                {STATES.map((state) => (
                  <SelectItem key={state} value={state}>
                    {state}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Leads Table */}
      <Card className="glass-card">
        <CardContent className="pt-6">
          {loading ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : filteredLeads.length === 0 ? (
            <div className="text-center py-12">
              <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No leads found</h3>
              <p className="text-muted-foreground">
                {searchQuery || statusFilter !== 'all' || stateFilter !== 'all'
                  ? 'Try adjusting your filters'
                  : 'Get started by adding your first lead'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto scrollbar-thin">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Institution</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLeads.map((lead) => (
                    <TableRow key={lead.id} className="group">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                            <GraduationCap className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium">{lead.institution_name}</p>
                            <p className="text-sm text-muted-foreground capitalize">
                              {lead.institution_type}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-sm">
                          <MapPin className="h-3 w-3 text-muted-foreground" />
                          {lead.city}, {lead.state}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <p className="text-sm font-medium">{lead.contact_person}</p>
                          <p className="text-xs text-muted-foreground">{lead.email}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Select
                          value={lead.lead_status}
                          onValueChange={(value) => handleStatusChange(lead.id, value as LeadStatus)}
                        >
                          <SelectTrigger className="w-[140px]">
                            <Badge className={getStatusColor(lead.lead_status)}>
                              {STATUS_OPTIONS.find((s) => s.value === lead.lead_status)?.label}
                            </Badge>
                          </SelectTrigger>
                          <SelectContent>
                            {STATUS_OPTIONS.map((status) => (
                              <SelectItem key={status.value} value={status.value}>
                                {status.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        {lead.priority_score ? (
                          <div className="flex items-center gap-2">
                            <div className="h-2 w-16 bg-secondary rounded-full overflow-hidden">
                              <div
                                className="h-full bg-primary rounded-full"
                                style={{ width: `${lead.priority_score}%` }}
                              />
                            </div>
                            <span className="text-sm font-medium">{lead.priority_score}</span>
                          </div>
                        ) : (
                          <Badge variant="outline" className="text-xs">
                            Not scored
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => { setSelectedLead(lead); setDetailDialogOpen(true); }}>
                              <Eye className="mr-2 h-4 w-4" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => generateAIInsights(lead)}>
                              <Sparkles className="mr-2 h-4 w-4" />
                              AI Analysis
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEdit(lead)}>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => { setSelectedLead(lead); setDeleteDialogOpen(true); }}
                              className="text-destructive focus:text-destructive"
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId ? 'Edit Lead' : 'Add New Lead'}</DialogTitle>
            <DialogDescription>
              {editingId ? 'Update institution information' : 'Enter details for new institution lead'}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Institution Name */}
              <div className="md:col-span-2 space-y-2">
                <Label htmlFor="institution_name">Institution Name *</Label>
                <Input
                  id="institution_name"
                  value={formData.institution_name}
                  onChange={(e) => setFormData({ ...formData, institution_name: e.target.value })}
                  placeholder="e.g., GLA University"
                  required
                />
              </div>

              {/* Institution Type */}
              <div className="space-y-2">
                <Label>Institution Type *</Label>
                <Select
                  value={formData.institution_type}
                  onValueChange={(value: InstitutionType) => setFormData({ ...formData, institution_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {INSTITUTION_TYPES.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Student Strength */}
              <div className="space-y-2">
                <Label htmlFor="student_strength">Student Strength</Label>
                <Input
                  id="student_strength"
                  type="number"
                  value={formData.student_strength}
                  onChange={(e) => setFormData({ ...formData, student_strength: parseInt(e.target.value) || 0 })}
                  placeholder="e.g., 5000"
                />
              </div>

              {/* City */}
              <div className="space-y-2">
                <Label htmlFor="city">City *</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  placeholder="e.g., Mathura"
                  required
                />
              </div>

              {/* State */}
              <div className="space-y-2">
                <Label>State *</Label>
                <Select
                  value={formData.state}
                  onValueChange={(value) => setFormData({ ...formData, state: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select state" />
                  </SelectTrigger>
                  <SelectContent>
                    {STATES.map((state) => (
                      <SelectItem key={state} value={state}>
                        {state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Contact Person */}
              <div className="space-y-2">
                <Label htmlFor="contact_person">Contact Person *</Label>
                <Input
                  id="contact_person"
                  value={formData.contact_person}
                  onChange={(e) => setFormData({ ...formData, contact_person: e.target.value })}
                  placeholder="e.g., Dr. Rajesh Kumar"
                  required
                />
              </div>

              {/* Designation */}
              <div className="space-y-2">
                <Label htmlFor="designation">Designation</Label>
                <Input
                  id="designation"
                  value={formData.designation}
                  onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                  placeholder="e.g., Training & Placement Officer"
                />
              </div>

              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="e.g., tpo@university.edu"
                  required
                />
              </div>

              {/* Phone */}
              <div className="space-y-2">
                <Label htmlFor="phone">Phone *</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="e.g., +91 9876543210"
                  required
                />
              </div>

              {/* Program Interest */}
              <div className="space-y-2">
                <Label>Program Interest</Label>
                <Select
                  value={formData.program_interest}
                  onValueChange={(value) => setFormData({ ...formData, program_interest: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select program" />
                  </SelectTrigger>
                  <SelectContent>
                    {PROGRAM_INTERESTS.map((program) => (
                      <SelectItem key={program} value={program}>
                        {program}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Lead Source */}
              <div className="space-y-2">
                <Label>Lead Source</Label>
                <Select
                  value={formData.lead_source}
                  onValueChange={(value) => setFormData({ ...formData, lead_source: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select source" />
                  </SelectTrigger>
                  <SelectContent>
                    {LEAD_SOURCES.map((source) => (
                      <SelectItem key={source} value={source}>
                        {source}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Next Follow-up Date */}
              <div className="space-y-2">
                <Label htmlFor="next_followup_date">Next Follow-up Date</Label>
                <Input
                  id="next_followup_date"
                  type="date"
                  value={formData.next_followup_date}
                  onChange={(e) => setFormData({ ...formData, next_followup_date: e.target.value })}
                />
              </div>

              {/* Notes */}
              <div className="md:col-span-2 space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Add any relevant notes about this institution..."
                  rows={3}
                />
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">{editingId ? 'Update Lead' : 'Create Lead'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedLead?.institution_name}</DialogTitle>
            <DialogDescription>
              {selectedLead?.institution_type} | {selectedLead?.city}, {selectedLead?.state}
            </DialogDescription>
          </DialogHeader>

          {selectedLead && (
            <div className="space-y-6">
              {/* Quick Info */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-secondary/50">
                  <p className="text-sm text-muted-foreground">Contact Person</p>
                  <p className="font-medium">{selectedLead.contact_person}</p>
                  <p className="text-sm">{selectedLead.designation}</p>
                </div>
                <div className="p-4 rounded-lg bg-secondary/50">
                  <p className="text-sm text-muted-foreground">Student Strength</p>
                  <p className="font-medium">{selectedLead.student_strength?.toLocaleString() || 'N/A'}</p>
                </div>
              </div>

              {/* Contact Info */}
              <div className="flex gap-4">
                <a
                  href={`mailto:${selectedLead.email}`}
                  className="flex items-center gap-2 text-primary hover:underline"
                >
                  <Mail className="h-4 w-4" />
                  {selectedLead.email}
                </a>
                <a
                  href={`tel:${selectedLead.phone}`}
                  className="flex items-center gap-2 text-primary hover:underline"
                >
                  <Phone className="h-4 w-4" />
                  {selectedLead.phone}
                </a>
              </div>

              {/* Status & AI Score */}
              <div className="flex items-center gap-4">
                <Badge className={getStatusColor(selectedLead.lead_status)}>
                  {STATUS_OPTIONS.find((s) => s.value === selectedLead.lead_status)?.label}
                </Badge>
                {selectedLead.priority_score && (
                  <Badge variant="outline">
                    Priority: {selectedLead.priority_score}/100
                  </Badge>
                )}
              </div>

              {/* Program Interest */}
              {selectedLead.program_interest && (
                <div>
                  <p className="text-sm text-muted-foreground">Program Interest</p>
                  <p className="font-medium">{selectedLead.program_interest}</p>
                </div>
              )}

              {/* Notes */}
              {selectedLead.notes && (
                <div>
                  <p className="text-sm text-muted-foreground">Notes</p>
                  <p className="text-sm bg-secondary/50 p-3 rounded-lg">{selectedLead.notes}</p>
                </div>
              )}

              {/* AI Insights */}
              {selectedLead.ai_insights && (
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="h-4 w-4 text-primary" />
                    <span className="font-medium">AI Insights</span>
                  </div>
                  <p className="text-sm">{selectedLead.ai_insights}</p>
                </div>
              )}

              {/* Dates */}
              <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                <div>Created: {format(new Date(selectedLead.created_at), 'PP')}</div>
                {selectedLead.next_followup_date && (
                  <div>Next Follow-up: {format(new Date(selectedLead.next_followup_date), 'PP')}</div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* AI Analysis Dialog */}
      <Dialog open={aiDialogOpen} onOpenChange={setAiDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              AI Lead Analysis
            </DialogTitle>
            <DialogDescription>
              {selectedLead?.institution_name}
            </DialogDescription>
          </DialogHeader>

          {aiLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-pulse flex flex-col items-center gap-4">
                <Sparkles className="h-12 w-12 text-primary animate-pulse-soft" />
                <p className="text-muted-foreground">Analyzing lead data...</p>
              </div>
            </div>
          ) : aiInsights ? (
            <div className="space-y-6">
              {/* Priority Score */}
              <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/50">
                <span className="font-medium">Priority Score</span>
                <div className="flex items-center gap-2">
                  <div className="h-3 w-24 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full"
                      style={{ width: `${aiInsights.priorityScore}%` }}
                    />
                  </div>
                  <span className="font-bold text-xl">{aiInsights.priorityScore}/100</span>
                </div>
              </div>

              {/* Potential Rating & Probability */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-secondary/50">
                  <p className="text-sm text-muted-foreground">Potential Rating</p>
                  <p className="text-xl font-bold capitalize">{aiInsights.potentialRating}</p>
                </div>
                <div className="p-4 rounded-lg bg-secondary/50">
                  <p className="text-sm text-muted-foreground">Partnership Probability</p>
                  <p className="text-xl font-bold">{aiInsights.partnershipProbability}%</p>
                </div>
              </div>

              {/* Recommended Action */}
              <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                <p className="text-sm text-muted-foreground mb-2">Recommended Action</p>
                <p className="font-medium">{aiInsights.recommendedAction}</p>
              </div>

              {/* Insights */}
              <div>
                <p className="text-sm text-muted-foreground mb-2">Key Insights</p>
                <p className="text-sm bg-secondary/50 p-3 rounded-lg">{aiInsights.insights}</p>
              </div>

              {/* Outreach Message */}
              <div>
                <p className="text-sm text-muted-foreground mb-2">Suggested Outreach Message</p>
                <p className="text-sm bg-secondary/50 p-3 rounded-lg italic">
                  {aiInsights.outreachMessage}
                </p>
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              Delete Lead
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {selectedLead?.institution_name}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
