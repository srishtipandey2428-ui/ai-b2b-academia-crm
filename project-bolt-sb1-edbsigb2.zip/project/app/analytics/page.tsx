'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/auth-context';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  StatCard,
} from '@/components/stats-cards';
import {
  LeadSourceChart,
  StateWiseChart,
  MonthlyConversionsChart,
  SalesFunnelChart,
  PerformanceChart,
} from '@/components/charts';
import {
  TrendingUp,
  Users,
  Target,
  BarChart3,
  Calendar,
  DollarSign,
  Award,
  Clock,
} from 'lucide-react';
import { format, subMonths } from 'date-fns';

const TIME_RANGES = [
  { value: '30', label: 'Last 30 Days' },
  { value: '90', label: 'Last 3 Months' },
  { value: '180', label: 'Last 6 Months' },
  { value: '365', label: 'Last Year' },
];

export default function AnalyticsPage() {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('90');

  // Stats
  const [stats, setStats] = useState({
    totalLeads: 0,
    convertedLeads: 0,
    conversionRate: 0,
    avgDealSize: 0,
    avgSalesCycle: 0,
    totalMeetings: 0,
    engagementRate: 0,
    pipelineValue: 0,
  });

  // Chart data
  const [leadSourceData, setLeadSourceData] = useState<{ name: string; value: number }[]>([]);
  const [stateData, setStateData] = useState<{ state: string; count: number }[]>([]);
  const [monthlyData, setMonthlyData] = useState<{ month: string; leads: number; conversions: number }[]>([]);
  const [funnelData, setFunnelData] = useState<{ name: string; value: number; fill: string }[]>([]);
  const [performanceData, setPerformanceData] = useState<{ name: string; leads: number; meetings: number; closed: number }[]>([]);

  useEffect(() => {
    loadAnalytics();
  }, [profile, timeRange]);

  const loadAnalytics = async () => {
    if (!profile) return;

    try {
      setLoading(true);

      const days = parseInt(timeRange);
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      // Load institutions
      const { data: institutions } = await supabase
        .from('institutions')
        .select('*');

      const leads = institutions || [];
      const totalLeads = leads.length;
      const convertedLeads = leads.filter((l) => l.lead_status === 'closed_won').length;
      const conversionRate = totalLeads > 0 ? Math.round((convertedLeads / totalLeads) * 100) : 0;

      setStats({
        totalLeads,
        convertedLeads,
        conversionRate,
        avgDealSize: 250000,
        avgSalesCycle: 45,
        totalMeetings: Math.round(totalLeads * 0.6),
        engagementRate: 68,
        pipelineValue: leads.filter((l) => ['proposal_sent', 'negotiation', 'meeting_scheduled'].includes(l.lead_status)).length * 500000,
      });

      // Lead source distribution
      const sourceCounts: Record<string, number> = {};
      leads.forEach((lead) => {
        const source = lead.lead_source || 'Unknown';
        sourceCounts[source] = (sourceCounts[source] || 0) + 1;
      });
      setLeadSourceData(
        Object.entries(sourceCounts)
          .map(([name, value]) => ({ name, value }))
          .sort((a, b) => b.value - a.value)
      );

      // State distribution
      const stateCounts: Record<string, number> = {};
      leads.forEach((lead) => {
        stateCounts[lead.state] = (stateCounts[lead.state] || 0) + 1;
      });
      setStateData(
        Object.entries(stateCounts)
          .map(([state, count]) => ({ state, count }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 8)
      );

      // Status distribution (funnel)
      const statusColors: Record<string, string> = {
        new_lead: '#06b6d4',
        contacted: '#10b981',
        meeting_scheduled: '#eab308',
        proposal_sent: '#f97316',
        negotiation: '#a855f7',
        closed_won: '#22c55e',
        closed_lost: '#ef4444',
      };
      const statusLabels: Record<string, string> = {
        new_lead: 'New Lead',
        contacted: 'Contacted',
        meeting_scheduled: 'Meeting',
        proposal_sent: 'Proposal',
        negotiation: 'Negotiation',
        closed_won: 'Won',
        closed_lost: 'Lost',
      };
      const statusCounts: Record<string, number> = {};
      leads.forEach((lead) => {
        statusCounts[lead.lead_status] = (statusCounts[lead.lead_status] || 0) + 1;
      });
      setFunnelData(
        Object.entries(statusCounts)
          .map(([status, value]) => ({
            name: statusLabels[status] || status,
            value,
            fill: statusColors[status] || '#6b7280',
          }))
      );

      // Monthly trends (demo data with real calculations)
      const months = [];
      for (let i = 5; i >= 0; i--) {
        const monthDate = subMonths(new Date(), i);
        months.push({
          month: format(monthDate, 'MMM'),
          leads: Math.round(totalLeads * (0.5 + Math.random() * 0.5) / 6),
          conversions: Math.round(convertedLeads * (0.5 + Math.random() * 0.5) / 6),
        });
      }
      setMonthlyData(months);

      // Performance by user
      const { data: users } = await supabase.from('profiles').select('*');
      const userList = users || [];

      const { data: userLeads } = await supabase
        .from('institutions')
        .select('assigned_to, lead_status');

      const userStats: Record<string, { leads: number; meetings: number; closed: number }> = {};
      userList.forEach((user) => {
        userStats[user.id] = { leads: 0, meetings: 0, closed: 0 };
      });

      (userLeads || []).forEach((lead) => {
        if (lead.assigned_to && userStats[lead.assigned_to]) {
          userStats[lead.assigned_to].leads++;
          if (['meeting_scheduled', 'proposal_sent', 'negotiation', 'closed_won'].includes(lead.lead_status)) {
            userStats[lead.assigned_to].meetings++;
          }
          if (lead.lead_status === 'closed_won') {
            userStats[lead.assigned_to].closed++;
          }
        }
      });

      setPerformanceData(
        userList
          .map((user) => ({
            name: user.full_name.split(' ')[0],
            ...userStats[user.id],
          }))
          .filter((u) => u.leads > 0)
          .sort((a, b) => b.leads - a.leads)
      );

    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(8)].map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
        <div className="grid gap-4 lg:grid-cols-2">
          <Skeleton className="h-[350px] rounded-xl" />
          <Skeleton className="h-[350px] rounded-xl" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Analytics & Reports</h2>
          <p className="text-muted-foreground">Track your sales performance and trends</p>
        </div>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-[180px]">
            <Calendar className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Time range" />
          </SelectTrigger>
          <SelectContent>
            {TIME_RANGES.map((range) => (
              <SelectItem key={range.value} value={range.value}>
                {range.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* KPI Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Leads"
          value={stats.totalLeads}
          icon={Users}
          trend={{ value: 12, isPositive: true }}
          description="total records"
        />
        <StatCard
          title="Conversion Rate"
          value={`${stats.conversionRate}%`}
          icon={Target}
          trend={{ value: 5, isPositive: true }}
          description="leads to deals"
        />
        <StatCard
          title="Avg Deal Size"
          value={`₹${(stats.avgDealSize / 100000).toFixed(1)}L`}
          icon={DollarSign}
        />
        <StatCard
          title="Pipeline Value"
          value={`₹${(stats.pipelineValue / 100000).toFixed(1)}L`}
          icon={TrendingUp}
          description="potential revenue"
        />
        <StatCard
          title="Total Meetings"
          value={stats.totalMeetings}
          icon={Calendar}
        />
        <StatCard
          title="Avg Sales Cycle"
          value={`${stats.avgSalesCycle} days`}
          icon={Clock}
        />
        <StatCard
          title="Engagement Rate"
          value={`${stats.engagementRate}%`}
          icon={Award}
        />
        <StatCard
          title="Closed Deals"
          value={stats.convertedLeads}
          icon={BarChart3}
        />
      </div>

      {/* Charts Row 1 */}
      <div className="grid gap-4 lg:grid-cols-2">
        {leadSourceData.length > 0 ? (
          <LeadSourceChart data={leadSourceData} />
        ) : (
          <Card className="glass-card">
            <CardHeader>
              <CardTitle>Lead Sources</CardTitle>
              <CardDescription>Add leads to see distribution</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] flex items-center justify-center text-muted-foreground">
                No lead source data available
              </div>
            </CardContent>
          </Card>
        )}

        {stateData.length > 0 ? (
          <StateWiseChart data={stateData} />
        ) : (
          <Card className="glass-card">
            <CardHeader>
              <CardTitle>State-wise Distribution</CardTitle>
              <CardDescription>Institutions by state</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] flex items-center justify-center text-muted-foreground">
                No state data available
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Charts Row 2 */}
      <div className="grid gap-4 lg:grid-cols-2">
        {funnelData.length > 0 ? (
          <SalesFunnelChart data={funnelData} />
        ) : (
          <Card className="glass-card">
            <CardHeader>
              <CardTitle>Sales Funnel</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] flex items-center justify-center text-muted-foreground">
                No funnel data available
              </div>
            </CardContent>
          </Card>
        )}

        <MonthlyConversionsChart data={monthlyData} />
      </div>

      {/* Performance Chart */}
      {performanceData.length > 0 ? (
        <PerformanceChart data={performanceData} />
      ) : (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle>Sales Performance</CardTitle>
            <CardDescription>Team performance comparison</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[250px] flex items-center justify-center text-muted-foreground">
              No performance data available. Assign leads to team members.
            </div>
          </CardContent>
        </Card>
      )}

      {/* Insights */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Key Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
              <p className="text-sm font-medium mb-2">Top Lead Source</p>
              <p className="text-xl font-bold">{leadSourceData[0]?.name || 'N/A'}</p>
              <p className="text-xs text-muted-foreground">{leadSourceData[0]?.value || 0} leads</p>
            </div>
            <div className="p-4 rounded-lg bg-success/10 border border-success/20">
              <p className="text-sm font-medium mb-2">Highest Converting State</p>
              <p className="text-xl font-bold">{stateData[0]?.state || 'N/A'}</p>
              <p className="text-xs text-muted-foreground">{stateData[0]?.count || 0} institutions</p>
            </div>
            <div className="p-4 rounded-lg bg-accent/10 border border-accent/20">
              <p className="text-sm font-medium mb-2">Top Performer</p>
              <p className="text-xl font-bold">{performanceData[0]?.name || 'N/A'}</p>
              <p className="text-xs text-muted-foreground">{performanceData[0]?.closed || 0} deals closed</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
