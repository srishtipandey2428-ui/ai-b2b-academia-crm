'use client';

import { useState, useRef, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/auth-context';
import { Institution, Profile } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import {
  Sparkles,
  Send,
  User,
  Bot,
  Search,
  TrendingUp,
  Target,
  AlertCircle,
  Lightbulb,
  MessageSquare,
  Loader2,
  ChevronDown,
} from 'lucide-react';
import { format } from 'date-fns';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  type?: 'text' | 'insight' | 'recommendation';
  data?: any;
}

const SUGGESTED_PROMPTS = [
  { text: 'Show me high priority leads', icon: Target },
  { text: 'What should I focus on today?', icon: Lightbulb },
  { text: 'Analyze my pipeline', icon: TrendingUp },
  { text: 'Leads needing follow-up', icon: AlertCircle },
];

export default function AIAssistantPage() {
  const { profile } = useAuth();
  const { toast } = useToast();

  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [leads, setLeads] = useState<Institution[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [leadsLoading, setLeadsLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadData();
  }, [profile]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadData = async () => {
    if (!profile) return;

    try {
      setLeadsLoading(true);

      const [leadsRes, usersRes] = await Promise.all([
        supabase
          .from('institutions')
          .select('*, assigned_user:profiles!assigned_to(*)')
          .order('priority_score', { ascending: false, nullsFirst: false }),
        supabase.from('profiles').select('*'),
      ]);

      setLeads(leadsRes.data || []);
      setUsers(usersRes.data || []);

      // Initial welcome message
      setMessages([
        {
          id: '1',
          role: 'assistant',
          content: `Welcome to AI Sales Assistant! I'm here to help you manage your leads and make data-driven decisions.\n\nHere's a quick overview:\n- You have **${leads.length}** total leads\n- **${leads.filter(l => l.lead_status === 'new_lead').length}** new leads waiting for action\n- **${leads.filter(l => l.priority_score && l.priority_score >= 70).length}** high-priority opportunities\n\nHow can I assist you today?`,
          timestamp: new Date(),
          type: 'text',
        },
      ]);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLeadsLoading(false);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await processQuery(input);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.text,
        timestamp: new Date(),
        type: response.type,
        data: response.data,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error processing query:', error);
      toast({
        title: 'Error',
        description: 'Failed to process your query',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const processQuery = async (query: string): Promise<{ text: string; type: 'text' | 'insight' | 'recommendation'; data?: any }> => {
    const lowerQuery = query.toLowerCase();

    // High priority leads
    if (lowerQuery.includes('high priority') || lowerQuery.includes('priority')) {
      const highPriority = leads.filter(l => l.priority_score && l.priority_score >= 70);
      return {
        text: `Found **${highPriority.length}** high-priority leads (score 70+):\n\n${highPriority.length > 0 ? highPriority.slice(0, 5).map((l, i) => `${i + 1}. **${l.institution_name}** - Score: ${l.priority_score}/100 (${l.city}, ${l.state})`).join('\n') : 'No high-priority leads found. Run AI analysis on your leads to generate priority scores.'}`,
        type: 'recommendation',
        data: highPriority.slice(0, 5),
      };
    }

    // Follow-up needed
    if (lowerQuery.includes('follow') || lowerQuery.includes('follow-up') || lowerQuery.includes('need attention')) {
      const needsFollowUp = leads.filter(l => {
        if (!l.next_followup_date) return l.lead_status === 'contacted';
        return new Date(l.next_followup_date) <= new Date();
      });
      return {
        text: `**${needsFollowUp.length}** leads require follow-up action:\n\n${needsFollowUp.slice(0, 5).map((l, i) => `${i + 1}. **${l.institution_name}** - ${l.next_followup_date ? `Due: ${format(new Date(l.next_followup_date), 'MMM d')}` : 'No follow-up scheduled'}`).join('\n')}\n\n\U0001D3\U0000D5 Recommendation: Prioritize these leads today to maintain engagement momentum.`,
        type: 'insight',
        data: needsFollowUp.slice(0, 5),
      };
    }

    // Focus on today
    if (lowerQuery.includes('focus') || lowerQuery.includes('today')) {
      const today = new Date();
      const newLeads = leads.filter(l => l.lead_status === 'new_lead');
      const highPriority = leads.filter(l => l.priority_score && l.priority_score >= 70 && l.lead_status !== 'closed_won');
      const needsFollowUp = leads.filter(l => !l.next_followup_date ? l.lead_status === 'contacted' : new Date(l.next_followup_date) <= today);

      return {
        text: `**Today's Priority Actions:**\n\n\U0001F331 **New Leads (${newLeads.length})** - Contact them within 24 hours for best conversion rates\n\n\U0001F4A1 **High Priority (${highPriority.length})** - Schedule meetings with high-score leads\n\n\U0001F4CD **Follow-ups Needed (${needsFollowUp.length})** - Touch base with overdue contacts\n\n**Top Recommendation:**\n${highPriority[0] ? `Call **${highPriority[0].institution_name}** (${highPriority[0].contact_person}) - Priority Score: ${highPriority[0].priority_score}` : 'Focus on converting existing leads'}`,
        type: 'recommendation',
      };
    }

    // Pipeline analysis
    if (lowerQuery.includes('pipeline') || lowerQuery.includes('analyze')) {
      const statusCounts: Record<string, number> = {};
      leads.forEach(l => {
        statusCounts[l.lead_status] = (statusCounts[l.lead_status] || 0) + 1;
      });

      const conversionRate = leads.length > 0
        ? Math.round((statusCounts['closed_won'] || 0) / leads.length * 100)
        : 0;

      return {
        text: `**Pipeline Analysis:**\n\n\U0001F4CA **Stage Distribution:**\n- New Leads: ${statusCounts['new_lead'] || 0}\n- Contacted: ${statusCounts['contacted'] || 0}\n- Meeting Scheduled: ${statusCounts['meeting_scheduled'] || 0}\n- Proposal Sent: ${statusCounts['proposal_sent'] || 0}\n- Negotiation: ${statusCounts['negotiation'] || 0}\n- Closed Won: ${statusCounts['closed_won'] || 0}\n- Closed Lost: ${statusCounts['closed_lost'] || 0}\n\n\U0001F4C8 **Key Metrics:**\n- Conversion Rate: ${conversionRate}%\n- Active Pipeline: ${(statusCounts['proposal_sent'] || 0) + (statusCounts['negotiation'] || 0)} deals\n\n\U0001D3\U0000D5 **Suggestions:**\n- Focus on moving ${statusCounts['contacted'] || 0} contacted leads to meetings\n- Follow up on ${statusCounts['proposal_sent'] || 0} pending proposals`,
        type: 'insight',
      };
    }

    // Search
    if (lowerQuery.includes('find') || lowerQuery.includes('search') || lowerQuery.includes('show')) {
      const searchTerm = query.replace(/find|search|show|me|all|leads/gi, '').trim().toLowerCase();
      const results = leads.filter(l =>
        l.institution_name.toLowerCase().includes(searchTerm) ||
        l.city.toLowerCase().includes(searchTerm) ||
        l.state.toLowerCase().includes(searchTerm) ||
        l.contact_person.toLowerCase().includes(searchTerm)
      );

      return {
        text: `Found **${results.length}** matching leads:\n\n${results.slice(0, 5).map((l, i) => `${i + 1}. **${l.institution_name}** (${l.city}, ${l.state}) - ${l.contact_person}`).join('\n')}`,
        type: 'text',
        data: results.slice(0, 5),
      };
    }

    // Default response
    return {
      text: `I can help you with:\n\n\U0001F331 **Lead Management**\n- "Show high priority leads"\n- "Find leads in Maharashtra"\n- "Leads needing follow-up"\n\n\U0001F4CA **Analytics**\n- "Analyze my pipeline"\n- "What should I focus on today?"\n- "Show conversion trends"\n\n\U0001D3\U0000D5 **Recommendations**\n- "What's the next best action?"\n- "How can I improve conversion?"\n\nAsk me anything about your sales data!`,
      type: 'text',
    };
  };

  const handlePromptClick = (prompt: string) => {
    setInput(prompt);
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex gap-6">
      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto scrollbar-thin space-y-4 pr-4">
          {leadsLoading ? (
            <div className="flex items-center justify-center h-full">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`flex gap-3 max-w-[80%] ${
                    message.role === 'user' ? 'flex-row-reverse' : ''
                  }`}
                >
                  <Avatar className="h-8 w-8 shrink-0">
                    <AvatarFallback
                      className={
                        message.role === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-gradient-to-br from-primary to-accent text-white'
                      }
                    >
                      {message.role === 'user' ? <User className="h-4 w-4" /> : <Sparkles className="h-4 w-4" />}
                    </AvatarFallback>
                  </Avatar>
                  <div
                    className={`rounded-2xl p-4 ${
                      message.role === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-secondary'
                    }`}
                  >
                    <div className="prose prose-sm max-w-none">
                      {message.content.split('\n').map((line, i) => (
                        <p key={i} className="mb-1 last:mb-0">
                          {line.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')}
                        </p>
                      ))}
                    </div>
                    <p className="text-xs opacity-70 mt-2">
                      {format(message.timestamp, 'p')}
                    </p>
                  </div>
                </div>
              </div>
            ))
          )}

          {loading && (
            <div className="flex justify-start">
              <div className="flex gap-3">
                <Avatar className="h-8 w-8 shrink-0">
                  <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white">
                    <Sparkles className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="bg-secondary rounded-2xl p-4">
                  <div className="flex gap-1">
                    <div className="h-2 w-2 bg-muted-foreground rounded-full animate-bounce" />
                    <div className="h-2 w-2 bg-muted-foreground rounded-full animate-bounce [animation-delay:0.2s]" />
                    <div className="h-2 w-2 bg-muted-foreground rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Prompts */}
        {messages.length <= 1 && (
          <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-thin">
            {SUGGESTED_PROMPTS.map((prompt, i) => (
              <Button
                key={i}
                variant="outline"
                className="shrink-0"
                onClick={() => handlePromptClick(prompt.text)}
              >
                <prompt.icon className="h-4 w-4 mr-2" />
                {prompt.text}
              </Button>
            ))}
          </div>
        )}

        {/* Input */}
        <div className="flex gap-3 pt-4 border-t border-border/50">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about your leads, pipeline, or get recommendations..."
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            className="flex-1"
          />
          <Button onClick={handleSend} disabled={loading || !input.trim()}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Side Panel */}
      <div className="w-80 shrink-0 hidden lg:block">
        <Card className="glass-card h-full">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Quick Stats
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-3 rounded-lg bg-secondary/50">
              <p className="text-sm text-muted-foreground">Total Leads</p>
              <p className="text-2xl font-bold">{leads.length}</p>
            </div>

            <div className="p-3 rounded-lg bg-secondary/50">
              <p className="text-sm text-muted-foreground">High Priority</p>
              <p className="text-2xl font-bold">{leads.filter(l => l.priority_score && l.priority_score >= 70).length}</p>
            </div>

            <div className="p-3 rounded-lg bg-secondary/50">
              <p className="text-sm text-muted-foreground">New Leads</p>
              <p className="text-2xl font-bold">{leads.filter(l => l.lead_status === 'new_lead').length}</p>
            </div>

            <div className="p-3 rounded-lg bg-primary/10 border border-primary/20">
              <p className="text-sm text-muted-foreground">Closed Won</p>
              <p className="text-2xl font-bold text-primary">
                {leads.filter(l => l.lead_status === 'closed_won').length}
              </p>
            </div>

            <div className="pt-4 border-t border-border/50">
              <h4 className="text-sm font-medium mb-3">Recent Leads</h4>
              <div className="space-y-2">
                {leads.slice(0, 5).map((lead) => (
                  <div
                    key={lead.id}
                    className="flex items-center justify-between p-2 rounded-lg bg-secondary/50 text-sm"
                  >
                    <div className="truncate flex-1">
                      <p className="font-medium truncate">{lead.institution_name}</p>
                      <p className="text-xs text-muted-foreground">{lead.city}</p>
                    </div>
                    {lead.priority_score && (
                      <Badge variant="outline" className="ml-2 shrink-0">
                        {lead.priority_score}
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
