'use client';

import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/auth-context';
import { Institution, LeadStatus } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  GraduationCap,
  MapPin,
  Users,
  Sparkles,
  GripVertical,
} from 'lucide-react';
import { format } from 'date-fns';

const COLUMNS: { status: LeadStatus; title: string; color: string }[] = [
  { status: 'new_lead', title: 'New Lead', color: 'bg-blue-500' },
  { status: 'contacted', title: 'Contacted', color: 'bg-cyan-500' },
  { status: 'meeting_scheduled', title: 'Meeting', color: 'bg-yellow-500' },
  { status: 'proposal_sent', title: 'Proposal', color: 'bg-orange-500' },
  { status: 'negotiation', title: 'Negotiation', color: 'bg-purple-500' },
  { status: 'closed_won', title: 'Won', color: 'bg-green-500' },
  { status: 'closed_lost', title: 'Lost', color: 'bg-red-500' },
];

interface DragItem {
  id: string;
  status: LeadStatus;
}

export default function PipelinePage() {
  const { profile } = useAuth();
  const { toast } = useToast();

  const [leads, setLeads] = useState<Institution[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLead, setSelectedLead] = useState<Institution | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [draggingId, setDraggingId] = useState<string | null>(null);

  useEffect(() => {
    loadLeads();
  }, [profile]);

  const loadLeads = async () => {
    if (!profile) return;

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('institutions')
        .select('*, assigned_user:profiles!assigned_to(*)')
        .order('priority_score', { ascending: false, nullsFirst: false });

      if (error) throw error;
      setLeads(data || []);
    } catch (error) {
      console.error('Error loading leads:', error);
      toast({
        title: 'Error',
        description: 'Failed to load pipeline data',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDragStart = (e: React.DragEvent, lead: Institution) => {
    setDraggingId(lead.id);
    e.dataTransfer.setData('text/plain', JSON.stringify({ id: lead.id, status: lead.lead_status }));
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = async (e: React.DragEvent, newStatus: LeadStatus) => {
    e.preventDefault();
    setDraggingId(null);

    try {
      const data = e.dataTransfer.getData('text/plain');
      const { id, status: oldStatus } = JSON.parse(data) as DragItem;

      if (oldStatus === newStatus) return;

      // Update lead status
      const { error } = await supabase
        .from('institutions')
        .update({ lead_status: newStatus })
        .eq('id', id);

      if (error) throw error;

      // Log activity
      await supabase.from('activities').insert([{
        institution_id: id,
        user_id: profile?.id,
        activity_type: 'status_change',
        title: `Moved to ${COLUMNS.find(c => c.status === newStatus)?.title}`,
        metadata: { old_status: oldStatus, new_status: newStatus },
      }]);

      // Update local state
      setLeads(prev =>
        prev.map(lead =>
          lead.id === id ? { ...lead, lead_status: newStatus } : lead
        )
      );

      toast({
        title: 'Success',
        description: `Lead moved to ${COLUMNS.find(c => c.status === newStatus)?.title}`,
      });
    } catch (error) {
      console.error('Error updating lead status:', error);
      toast({
        title: 'Error',
        description: 'Failed to update lead status',
        variant: 'destructive',
      });
    }
  };

  const getLeadsByStatus = (status: LeadStatus) => {
    return leads.filter(lead => lead.lead_status === status);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold">Sales Pipeline</h2>
        <p className="text-muted-foreground">Drag and drop leads to update their status</p>
      </div>

      {/* Pipeline Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
        {COLUMNS.map((column) => {
          const count = getLeadsByStatus(column.status).length;
          return (
            <Card key={column.status} className="glass-card">
              <CardContent className="pt-4 pb-3 px-4">
                <div className="flex items-center gap-2 mb-1">
                  <div className={`h-3 w-3 rounded-full ${column.color}`} />
                  <span className="text-sm font-medium truncate">{column.title}</span>
                </div>
                <span className="text-2xl font-bold">{count}</span>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Kanban Board */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-4">
          {[...Array(7)].map((_, i) => (
            <div key={i} className="space-y-3">
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-24 w-full" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-4 overflow-x-auto pb-4">
          {COLUMNS.map((column) => (
            <div
              key={column.status}
              className="min-w-[280px]"
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, column.status)}
            >
              {/* Column Header */}
              <div className="flex items-center gap-2 mb-3 px-1">
                <div className={`h-3 w-3 rounded-full ${column.color}`} />
                <h3 className="font-semibold">{column.title}</h3>
                <Badge variant="secondary" className="ml-auto">
                  {getLeadsByStatus(column.status).length}
                </Badge>
              </div>

              {/* Column Cards */}
              <div className="space-y-3">
                {getLeadsByStatus(column.status).map((lead) => (
                  <Card
                    key={lead.id}
                    className={`glass-card cursor-grab active:cursor-grabbing transition-all hover:shadow-md ${
                      draggingId === lead.id ? 'opacity-50 scale-95' : ''
                    }`}
                    draggable
                    onDragStart={(e) => handleDragStart(e, lead)}
                    onClick={() => { setSelectedLead(lead); setDetailOpen(true); }}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <GripVertical className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100" />
                          <GraduationCap className="h-4 w-4 text-primary" />
                        </div>
                        {lead.priority_score && (
                          <Badge variant="outline" className="text-xs">
                            {lead.priority_score}
                          </Badge>
                        )}
                      </div>

                      <h4 className="font-medium text-sm mb-1 line-clamp-2">
                        {lead.institution_name}
                      </h4>

                      <div className="flex items-center gap-1 text-xs text-muted-foreground mb-2">
                        <MapPin className="h-3 w-3" />
                        {lead.city}, {lead.state}
                      </div>

                      {lead.student_strength && (
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Users className="h-3 w-3" />
                          {lead.student_strength.toLocaleString()} students
                        </div>
                      )}

                      {lead.program_interest && (
                        <Badge variant="secondary" className="mt-2 text-xs">
                          {lead.program_interest}
                        </Badge>
                      )}
                    </CardContent>
                  </Card>
                ))}

                {getLeadsByStatus(column.status).length === 0 && (
                  <Card className="glass-card border-dashed">
                    <CardContent className="p-4 text-center text-muted-foreground text-sm">
                      No leads
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <GraduationCap className="h-5 w-5 text-primary" />
              {selectedLead?.institution_name}
            </DialogTitle>
            <DialogDescription>
              {selectedLead?.institution_type} | {selectedLead?.city}, {selectedLead?.state}
            </DialogDescription>
          </DialogHeader>

          {selectedLead && (
            <div className="space-y-4">
              {/* Priority Score */}
              {selectedLead.priority_score && (
                <div className="flex items-center gap-4">
                  <span className="text-sm text-muted-foreground">Priority Score</span>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-20 bg-secondary rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full"
                        style={{ width: `${selectedLead.priority_score}%` }}
                      />
                    </div>
                    <span className="font-medium">{selectedLead.priority_score}</span>
                  </div>
                </div>
              )}

              {/* Contact Info */}
              <div className="p-3 rounded-lg bg-secondary/50 space-y-2">
                <p className="text-sm"><strong>Contact:</strong> {selectedLead.contact_person}</p>
                <p className="text-sm"><strong>Email:</strong> {selectedLead.email}</p>
                <p className="text-sm"><strong>Phone:</strong> {selectedLead.phone}</p>
              </div>

              {/* Student Strength */}
              {selectedLead.student_strength && (
                <div className="flex items-center gap-2 text-sm">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span>{selectedLead.student_strength.toLocaleString()} students</span>
                </div>
              )}

              {/* Program Interest */}
              {selectedLead.program_interest && (
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-muted-foreground" />
                  <Badge>{selectedLead.program_interest}</Badge>
                </div>
              )}

              {/* AI Insights */}
              {selectedLead.ai_insights && (
                <div className="p-3 rounded-lg bg-primary/10 border border-primary/20">
                  <div className="flex items-center gap-2 mb-1">
                    <Sparkles className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium">AI Insights</span>
                  </div>
                  <p className="text-sm">{selectedLead.ai_insights}</p>
                </div>
              )}

              {/* Created Date */}
              <p className="text-xs text-muted-foreground">
                Created {format(new Date(selectedLead.created_at), 'PP')}
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
