'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/auth-context';
import { StatCard } from '@/components/stats-cards';
import {
  LeadSourceChart,
  StateWiseChart,
  MonthlyConversionsChart,
  SalesFunnelChart,
  PerformanceChart,
} from '@/components/charts';
import { Institution, Profile, Activity } from '@/lib/types';
import {
  Users,
  UserPlus,
  TrendingUp,
  Calendar,
  FileText,
  CheckCircle,
  BarChart,
  DollarSign,
  Clock,
  AlertCircle,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { format } from 'date-fns';

const STATUS_COLORS: Record<string, string> = {
  new_lead: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
  contacted: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900 dark:text-cyan-300',
  meeting_scheduled: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300',
  proposal_sent: 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300',
  negotiation: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
  closed_won: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
  closed_lost: 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300',
};

const STATUS_LABELS: Record<string, string> = {
  new_lead: 'New Lead',
  contacted: 'Contacted',
  meeting_scheduled: 'Meeting Scheduled',
  proposal_sent: 'Proposal Sent',
  negotiation: 'Negotiation',
  closed_won: 'Closed Won',
  closed_lost: 'Closed Lost',
};

export default function DashboardPage() {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    total_institutions: 0,
    new_leads: 0,
    active_leads: 0,
    meetings_scheduled: 0,
    proposals_sent: 0,
    closed_deals: 0,
    conversion_rate: 0,
    revenue_pipeline: 0,
  });
  const [recentLeads, setRecentLeads] = useState<Institution[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [upcomingMeetings, setUpcomingMeetings] = useState<any[]>([]);
  const [leadSourceData, setLeadSourceData] = useState<{ name: string; value: number }[]>([]);
  const [stateData, setStateData] = useState<{ state: string; count: number }[]>([]);
  const [monthlyData, setMonthlyData] = useState<{ month: string; leads: number; conversions: number }[]>([]);
  const [funnelData, setFunnelData] = useState<{ name: string; value: number; fill: string }[]>([]);
  const [performanceData, setPerformanceData] = useState<{ name: string; leads: number; meetings: number; closed: number }[]>([]);

  useEffect(() => {
    loadDashboardData();
  }, [profile]);

  const loadDashboardData = async () => {
    if (!profile) return;

    try {
      setLoading(true);

      // Load institutions count
      const { count: totalInstitutions } = await supabase
        .from('institutions')
        .select('*', { count: 'exact', head: true });

      const { count: newLeads } = await supabase
        .from('institutions')
        .select('*', { count: 'exact', head: true })
        .eq('lead_status', 'new_lead');

      const { count: activeLeads } = await supabase
        .from('institutions')
        .select('*', { count: 'exact', head: true })
        .in('lead_status', ['contacted', 'meeting_scheduled', 'proposal_sent', 'negotiation']);

      const { count: meetingsScheduled } = await supabase
        .from('meetings')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'scheduled')
        .gte('meeting_date', new Date().toISOString());

      const { count: proposalsSent } = await supabase
        .from('institutions')
        .select('*', { count: 'exact', head: true })
        .eq('lead_status', 'proposal_sent');

      const { count: closedDeals } = await supabase
        .from('institutions')
        .select('*', { count: 'exact', head: true })
        .eq('lead_status', 'closed_won');

      const conversionRate = totalInstitutions && closedDeals
        ? Math.round((closedDeals / totalInstitutions) * 100)
        : 0;

      setStats({
        total_institutions: totalInstitutions || 0,
        new_leads: newLeads || 0,
        active_leads: activeLeads || 0,
        meetings_scheduled: meetingsScheduled || 0,
        proposals_sent: proposalsSent || 0,
        closed_deals: closedDeals || 0,
        conversion_rate: conversionRate,
        revenue_pipeline: (activeLeads || 0) * 500000,
      });

      // Load recent leads
      const { data: leadsData } = await supabase
        .from('institutions')
        .select('*, assigned_user:profiles!assigned_to(*)')
        .order('created_at', { ascending: false })
        .limit(5);
      setRecentLeads(leadsData || []);

      // Load recent activities
      const { data: activitiesData } = await supabase
        .from('activities')
        .select('*, user:profiles(*)')
        .order('created_at', { ascending: false })
        .limit(10);
      setActivities(activitiesData || []);

      // Load upcoming meetings
      const { data: meetingsData } = await supabase
        .from('meetings')
        .select('*, institution:institutions(*)')
        .eq('status', 'scheduled')
        .gte('meeting_date', new Date().toISOString())
        .order('meeting_date', { ascending: true })
        .limit(5);
      setUpcomingMeetings(meetingsData || []);

      // Load lead source data
      const { data: sourceData } = await supabase
        .from('institutions')
        .select('lead_source');
      const sourceCounts = (sourceData || []).reduce((acc: Record<string, number>, curr) => {
        const source = curr.lead_source || 'Unknown';
        acc[source] = (acc[source] || 0) + 1;
        return acc;
      }, {});
      setLeadSourceData(
        Object.entries(sourceCounts).map(([name, value]) => ({ name, value }))
      );

      // Load state data
      const { data: stateCounts } = await supabase
        .from('institutions')
        .select('state');
      const stateMap = (stateCounts || []).reduce((acc: Record<string, number>, curr) => {
        acc[curr.state] = (acc[curr.state] || 0) + 1;
        return acc;
      }, {});
      setStateData(
        Object.entries(stateMap).map(([state, count]) => ({ state, count }))
      );

      // Load status distribution for funnel
      const { data: statusData } = await supabase
        .from('institutions')
        .select('lead_status');
      const statusCounts = (statusData || []).reduce((acc: Record<string, number>, curr) => {
        acc[curr.lead_status] = (acc[curr.lead_status] || 0) + 1;
        return acc;
      }, {});
      setFunnelData(
        Object.entries(statusCounts).map(([name, value]) => ({
          name: STATUS_LABELS[name] || name,
          value,
          fill: STATUS_COLORS[name]?.replace('bg-', '').replace(' text-[\\w-]+', '') || 'bg-gray-500',
        }))
      );

      // Demo monthly data
      setMonthlyData([
        { month: 'Jan', leads: 12, conversions: 4 },
        { month: 'Feb', leads: 15, conversions: 6 },
        { month: 'Mar', leads: 18, conversions: 8 },
        { month: 'Apr', leads: 22, conversions: 10 },
        { month: 'May', leads: 25, conversions: 12 },
        { month: 'Jun', leads: 28, conversions: 15 },
      ]);

      // Demo performance data
      setPerformanceData([
        { name: 'Rahul S.', leads: 25, meetings: 12, closed: 5 },
        { name: 'Priya M.', leads: 20, meetings: 10, closed: 4 },
        { name: 'Amit K.', leads: 18, meetings: 8, closed: 3 },
        { name: 'Neha P.', leads: 15, meetings: 6, closed: 2 },
      ]);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getInitials = (name: string) => {
    return name
      ?.split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2) || 'U';
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(8)].map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Institutions"
          value={stats.total_institutions}
          icon={Users}
          trend={{ value: 12, isPositive: true }}
          description="from last month"
        />
        <StatCard
          title="New Leads"
          value={stats.new_leads}
          icon={UserPlus}
          trend={{ value: 8, isPositive: true }}
          description="this week"
        />
        <StatCard
          title="Active Leads"
          value={stats.active_leads}
          icon={TrendingUp}
          description="In pipeline"
        />
        <StatCard
          title="Meetings Scheduled"
          value={stats.meetings_scheduled}
          icon={Calendar}
          trend={{ value: 5, isPositive: true }}
          description="upcoming"
        />
        <StatCard
          title="Proposals Sent"
          value={stats.proposals_sent}
          icon={FileText}
        />
        <StatCard
          title="Closed Deals"
          value={stats.closed_deals}
          icon={CheckCircle}
          trend={{ value: 15, isPositive: true }}
          description="this month"
        />
        <StatCard
          title="Conversion Rate"
          value={`${stats.conversion_rate}%`}
          icon={BarChart}
        />
        <StatCard
          title="Revenue Pipeline"
          value={`₹${(stats.revenue_pipeline / 100000).toFixed(1)}L`}
          icon={DollarSign}
          description="potential value"
        />
      </div>

      {/* Charts Row 1 */}
      <div className="grid gap-4 lg:grid-cols-2">
        <LeadSourceChart data={leadSourceData.length > 0 ? leadSourceData : [
          { name: 'Website', value: 30 },
          { name: 'Referral', value: 25 },
          { name: 'Campaign', value: 20 },
          { name: 'Event', value: 15 },
          { name: 'Other', value: 10 },
        ]} />
        <StateWiseChart data={stateData.length > 0 ? stateData : [
          { state: 'Maharashtra', count: 15 },
          { state: 'Karnataka', count: 12 },
          { state: 'Tamil Nadu', count: 10 },
          { state: 'Gujarat', count: 8 },
          { state: 'Delhi', count: 6 },
        ]} />
      </div>

      {/* Charts Row 2 */}
      <div className="grid gap-4 lg:grid-cols-2">
        <SalesFunnelChart data={funnelData.length > 0 ? funnelData : [
          { name: 'New Lead', value: 50, fill: '#06b6d4' },
          { name: 'Contacted', value: 40, fill: '#10b981' },
          { name: 'Meeting', value: 30, fill: '#f59e0b' },
          { name: 'Proposal', value: 20, fill: '#f97316' },
          { name: 'Negotiation', value: 15, fill: '#8b5cf6' },
          { name: 'Won', value: 10, fill: '#22c55e' },
        ]} />
        <MonthlyConversionsChart data={monthlyData} />
      </div>

      {/* Performance Chart */}
      <PerformanceChart data={performanceData} />

      {/* Bottom Section */}
      <div className="grid gap-4 lg:grid-cols-3">
        {/* Recent Leads */}
        <Card className="glass-card lg:col-span-2">
          <CardHeader>
            <CardTitle>Recent Leads</CardTitle>
            <CardDescription>Latest institution inquiries</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentLeads.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">No leads yet</p>
              ) : (
                recentLeads.map((lead) => (
                  <div
                    key={lead.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback className="bg-primary/20 text-primary">
                          {lead.institution_name[0]}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{lead.institution_name}</p>
                        <p className="text-sm text-muted-foreground">
                          {lead.city}, {lead.state}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className={STATUS_COLORS[lead.lead_status]}>
                        {STATUS_LABELS[lead.lead_status]}
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">
                        {lead.priority_score && `Score: ${lead.priority_score}`}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Meetings */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Upcoming Meetings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingMeetings.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">No upcoming meetings</p>
              ) : (
                upcomingMeetings.map((meeting) => (
                  <div
                    key={meeting.id}
                    className="p-3 rounded-lg bg-secondary/50"
                  >
                    <p className="font-medium text-sm">{meeting.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {meeting.institution?.institution_name}
                    </p>
                    <p className="text-xs text-primary mt-1">
                      {format(new Date(meeting.meeting_date), 'MMM d, p')}
                    </p>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Activity Timeline */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-4 w-4" />
            Recent Activity
          </CardTitle>
          <CardDescription>Latest actions across your team</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {activities.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No recent activity</p>
            ) : (
              activities.slice(0, 5).map((activity) => (
                <div
                  key={activity.id}
                  className="flex items-start gap-3 p-3 rounded-lg bg-secondary/50"
                >
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{getInitials(activity.user?.full_name || '')}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="text-sm">
                      <span className="font-medium">{activity.user?.full_name}</span>{' '}
                      {activity.title}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {format(new Date(activity.created_at), 'MMM d, p')}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
