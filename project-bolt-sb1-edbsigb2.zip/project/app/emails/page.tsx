'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/auth-context';
import { Email, Institution, EmailType } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Mail,
  Send,
  Inbox,
  FileText,
  Sparkles,
  Clock,
  CheckCircle,
  Eye,
  Search,
  Building2,
  Copy,
  Download,
} from 'lucide-react';
import { format } from 'date-fns';

const EMAIL_TYPES: { value: EmailType; label: string }[] = [
  { value: 'introduction', label: 'Introduction Email' },
  { value: 'proposal_followup', label: 'Proposal Follow-up' },
  { value: 'meeting_reminder', label: 'Meeting Reminder' },
  { value: 'partnership_proposal', label: 'Partnership Proposal' },
  { value: 'custom', label: 'Custom Email' },
];

const EMAIL_STATUS_COLORS: Record<string, string> = {
  draft: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300',
  sent: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
  delivered: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900 dark:text-cyan-300',
  opened: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300',
  replied: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
};

const EMAIL_TEMPLATES: Record<EmailType, { subject: string; body: string }> = {
  introduction: {
    subject: 'Exploring Industry-Academia Partnership Opportunities',
    body: `Dear [Contact Person],

I hope this message finds you well. I am reaching out from [Company Name] regarding potential collaboration opportunities with [Institution Name].

We specialize in industry-relevant technical training and internship programs that help bridge the gap between academic curriculum and industry requirements. Our programs have successfully trained 10,000+ students across 50+ institutions.

I would be delighted to schedule a brief call to discuss how we can collaborate to enhance your students' industry readiness and career opportunities.

Looking forward to connecting with you.

Best regards,
[Your Name]
[Company Name] | [Phone] | [Email]`,
  },
  proposal_followup: {
    subject: 'Following Up on Partnership Proposal - [Institution Name]',
    body: `Dear [Contact Person],

I wanted to follow up on the partnership proposal we shared with you last week regarding collaboration opportunities for [Institution Name].

I understand that reviewing such proposals takes time, and I wanted to check if you had any questions or needed any additional information.

Some key highlights of our program:
- Industry-recognized certifications
- 95% placement assistance
- Hands-on project experience
- Continuous assessment and feedback

Would you be available for a call this week to discuss next steps?

Best regards,
[Your Name]`,
  },
  meeting_reminder: {
    subject: 'Reminder: Meeting on [Date] - [Institution Name]',
    body: `Dear [Contact Person],

This is a friendly reminder about our scheduled meeting on [Date] at [Time].

Meeting Details:
- Date: [Date]
- Time: [Time]
- Duration: [Duration]
- Type: [Virtual/In Person]
- Location/Link: [Details]

Agenda:
1. Understanding current training programs
2. Discussing collaboration opportunities
3. Q&A

Please let me know if you need to reschedule.

Looking forward to our conversation!

Best regards,
[Your Name]`,
  },
  partnership_proposal: {
    subject: 'Partnership Proposal for [Institution Name]',
    body: `Dear [Contact Person],

Thank you for your interest in exploring a partnership with us. I'm pleased to share a comprehensive proposal tailored to [Institution Name].

PROPOSAL OVERVIEW:

Program: [Program Name]
Duration: [Duration]
Students Covered: [Number]
Investment: [Amount]

KEY BENEFITS:
• Industry-recognized certification for students
• Practical, hands-on training modules
• Placement assistance and career guidance
• Faculty development programs
• Industry exposure through live projects

NEXT STEPS:
1. Review the attached proposal document
2. Schedule a discussion to address questions
3. Customize the program based on your requirements
4. Sign the Memorandum of Understanding

I would be happy to walk you through the proposal in detail. Please let me know a convenient time for a call.

Best regards,
[Your Name]`,
  },
  custom: {
    subject: '',
    body: '',
  },
};

export default function EmailsPage() {
  const { profile } = useAuth();
  const { toast } = useToast();

  const [emails, setEmails] = useState<Email[]>([]);
  const [institutions, setInstitutions] = useState<Institution[]>([]);
  const [loading, setLoading] = useState(true);
  const [composeOpen, setComposeOpen] = useState(false);
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [viewEmailOpen, setViewEmailOpen] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    institution_id: '',
    subject: '',
    body: '',
    email_type: 'custom' as EmailType,
  });

  useEffect(() => {
    loadData();
  }, [profile]);

  const loadData = async () => {
    if (!profile) return;

    try {
      setLoading(true);

      const [emailsRes, institutionsRes] = await Promise.all([
        supabase
          .from('emails')
          .select('*, institution:institutions(*), user:profiles(*)')
          .order('created_at', { ascending: false }),
        supabase.from('institutions').select('*'),
      ]);

      setEmails(emailsRes.data || []);
      setInstitutions(institutionsRes.data || []);
    } catch (error) {
      console.error('Error loading data:', error);
      toast({
        title: 'Error',
        description: 'Failed to load emails',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSendEmail = async () => {
    if (!profile || !formData.subject || !formData.body) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    try {
      const { error } = await supabase.from('emails').insert([{
        institution_id: formData.institution_id || null,
        subject: formData.subject,
        body: formData.body,
        email_type: formData.email_type,
        status: 'sent',
        user_id: profile.id,
      }]);

      if (error) throw error;

      // Log activity
      if (formData.institution_id) {
        await supabase.from('activities').insert([{
          institution_id: formData.institution_id,
          user_id: profile.id,
          activity_type: 'email',
          title: `Sent ${EMAIL_TYPES.find(t => t.value === formData.email_type)?.label}`,
          metadata: { subject: formData.subject },
        }]);
      }

      toast({
        title: 'Success',
        description: 'Email saved to communication history',
      });

      setComposeOpen(false);
      setFormData({ institution_id: '', subject: '', body: '', email_type: 'custom' });
      loadData();
    } catch (error) {
      console.error('Error sending email:', error);
      toast({
        title: 'Error',
        description: 'Failed to send email',
        variant: 'destructive',
      });
    }
  };

  const handleTemplateSelect = (type: EmailType) => {
    const template = EMAIL_TEMPLATES[type];
    setFormData({
      ...formData,
      email_type: type,
      subject: template.subject,
      body: template.body,
    });
  };

  const handleInstitutionSelect = (institutionId: string) => {
    const institution = institutions.find((i) => i.id === institutionId);
    if (institution) {
      setFormData((prev) => ({
        ...prev,
        institution_id: institutionId,
        subject: prev.subject.replace('[Institution Name]', institution.institution_name),
        body: prev.body
          .replace('[Institution Name]', institution.institution_name)
          .replace('[Contact Person]', institution.contact_person),
      }));
    } else {
      setFormData((prev) => ({ ...prev, institution_id: '' }));
    }
  };

  const generateAIEmail = async () => {
    if (!formData.institution_id) {
      toast({
        title: 'Error',
        description: 'Please select an institution first',
        variant: 'destructive',
      });
      return;
    }

    setAiGenerating(true);

    try {
      const institution = institutions.find((i) => i.id === formData.institution_id);
      const response = await fetch('/api/ai/generate-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          institution,
          emailType: formData.email_type,
        }),
      });

      const data = await response.json();
      setFormData((prev) => ({
        ...prev,
        subject: data.subject,
        body: data.body,
      }));

      toast({
        title: 'Success',
        description: 'AI-generated email ready for review',
      });
    } catch (error) {
      console.error('Error generating email:', error);
      toast({
        title: 'Error',
        description: 'Failed to generate AI email',
        variant: 'destructive',
      });
    } finally {
      setAiGenerating(false);
    }
  };

  const sentEmails = emails.filter((e) => e.status !== 'draft');
  const inboxEmails = emails.filter((e) => e.status === 'replied');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Email Center</h2>
          <p className="text-muted-foreground">Manage your email communications</p>
        </div>
        <Button onClick={() => setComposeOpen(true)}>
          <Send className="h-4 w-4 mr-2" />
          Compose Email
        </Button>
      </div>

      {/* Email Tabs */}
      <Tabs defaultValue="sent">
        <TabsList>
          <TabsTrigger value="sent">
            <Send className="h-4 w-4 mr-2" />
            Sent ({sentEmails.length})
          </TabsTrigger>
          <TabsTrigger value="replies">
            <Inbox className="h-4 w-4 mr-2" />
            Replies ({inboxEmails.length})
          </TabsTrigger>
          <TabsTrigger value="templates">
            <FileText className="h-4 w-4 mr-2" />
            Templates
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sent" className="mt-4">
          <Card className="glass-card">
            <CardContent className="pt-6">
              {loading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-20 w-full" />
                  ))}
                </div>
              ) : sentEmails.length === 0 ? (
                <div className="text-center py-12">
                  <Mail className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">No emails sent yet</h3>
                  <p className="text-muted-foreground">
                    Compose your first email to get started
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {sentEmails.map((email) => (
                    <div
                      key={email.id}
                      className="flex items-start justify-between p-4 rounded-lg bg-secondary/50 hover:bg-secondary cursor-pointer transition-colors"
                      onClick={() => { setSelectedEmail(email); setViewEmailOpen(true); }}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={EMAIL_STATUS_COLORS[email.status]}>
                            {email.status}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {EMAIL_TYPES.find((t) => t.value === email.email_type)?.label}
                          </span>
                        </div>
                        <p className="font-medium">{email.subject}</p>
                        <p className="text-sm text-muted-foreground">
                          To: {email.institution?.institution_name || 'N/A'}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {format(new Date(email.sent_at), 'PPp')}
                        </p>
                      </div>
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="replies" className="mt-4">
          <Card className="glass-card">
            <CardContent className="pt-6">
              {inboxEmails.length === 0 ? (
                <div className="text-center py-12">
                  <Inbox className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">No replies yet</h3>
                  <p className="text-muted-foreground">
                    Replies from institutions will appear here
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {inboxEmails.map((email) => (
                    <div
                      key={email.id}
                      className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary cursor-pointer transition-colors"
                    >
                      <p className="font-medium">{email.institution?.institution_name}</p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(email.sent_at), 'PPp')}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2">
            {EMAIL_TYPES.filter((t) => t.value !== 'custom').map((type) => (
              <Card key={type.value} className="glass-card cursor-pointer hover:border-primary/50 transition-colors">
                <CardHeader>
                  <CardTitle className="text-lg">{type.label}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground truncate">
                    {EMAIL_TEMPLATES[type.value].subject}
                  </p>
                  <Button
                    variant="outline"
                    className="mt-4 w-full"
                    onClick={() => {
                      handleTemplateSelect(type.value);
                      setComposeOpen(true);
                    }}
                  >
                    Use Template
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Compose Email Dialog */}
      <Dialog open={composeOpen} onOpenChange={setComposeOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Compose Email</DialogTitle>
            <DialogDescription>
              Create and send an email to an institution
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Institution */}
            <div className="space-y-2">
              <Label>To (Institution)</Label>
              <div className="flex gap-2">
                <Select
                  value={formData.institution_id}
                  onValueChange={handleInstitutionSelect}
                >
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Select institution" />
                  </SelectTrigger>
                  <SelectContent>
                    {institutions.map((inst) => (
                      <SelectItem key={inst.id} value={inst.id}>
                        {inst.institution_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {formData.institution_id && (
                  <Button
                    variant="outline"
                    onClick={generateAIEmail}
                    disabled={aiGenerating}
                  >
                    {aiGenerating ? (
                      <Sparkles className="h-4 w-4 animate-pulse" />
                    ) : (
                      <Sparkles className="h-4 w-4 mr-2" />
                    )}
                    AI Generate
                  </Button>
                )}
              </div>
            </div>

            {/* Email Type */}
            <div className="space-y-2">
              <Label>Email Type</Label>
              <Select
                value={formData.email_type}
                onValueChange={(value) => handleTemplateSelect(value as EmailType)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {EMAIL_TYPES.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Subject */}
            <div className="space-y-2">
              <Label>Subject</Label>
              <div className="flex gap-2">
                <Input
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  placeholder="Email subject..."
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => navigator.clipboard.writeText(formData.subject)}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Body */}
            <div className="space-y-2">
              <Label>Body</Label>
              <Textarea
                value={formData.body}
                onChange={(e) => setFormData({ ...formData, body: e.target.value })}
                placeholder="Email body..."
                rows={12}
                className="font-mono text-sm"
              />
            </div>

            {/* Actions */}
            <div className="flex justify-between gap-2">
              <Button
                variant="outline"
                onClick={() => navigator.clipboard.writeText(formData.body)}
              >
                <Copy className="h-4 w-4 mr-2" />
                Copy to Clipboard
              </Button>
              <Button onClick={handleSendEmail}>
                <Send className="h-4 w-4 mr-2" />
                Save to History
              </Button>
            </div>

            <p className="text-xs text-muted-foreground text-center">
              Note: Emails are saved to your communication history. Use the copy button to paste in your email client.
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Email Dialog */}
      <Dialog open={viewEmailOpen} onOpenChange={setViewEmailOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedEmail?.subject}</DialogTitle>
            <DialogDescription>
              {selectedEmail?.institution?.institution_name}
            </DialogDescription>
          </DialogHeader>

          {selectedEmail && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Badge className={EMAIL_STATUS_COLORS[selectedEmail.status]}>
                  {selectedEmail.status}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {format(new Date(selectedEmail.sent_at), 'PPp')}
                </span>
              </div>

              <div className="p-4 rounded-lg bg-secondary/50 font-mono text-sm whitespace-pre-wrap">
                {selectedEmail.body}
              </div>

              <div className="flex gap-2 justify-end">
                <Button
                  variant="outline"
                  onClick={() => navigator.clipboard.writeText(selectedEmail.body)}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Body
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
