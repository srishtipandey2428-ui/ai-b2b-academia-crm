'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/auth-context';
import { Meeting, Institution, MeetingStatus, MeetingType } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Calendar,
  Video,
  Phone,
  MapPin,
  Clock,
  Plus,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  CalendarCheck,
} from 'lucide-react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday, addMonths, subMonths } from 'date-fns';

const MEETING_TYPES = [
  { value: 'virtual' as MeetingType, label: 'Virtual' },
  { value: 'in_person' as MeetingType, label: 'In Person' },
  { value: 'phone' as MeetingType, label: 'Phone' },
];

const MEETING_STATUS_COLORS = {
  scheduled: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
  completed: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
  cancelled: 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300',
  rescheduled: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300',
};

interface MeetingFormData {
  title: string;
  description: string;
  meeting_date: string;
  meeting_time: string;
  duration_minutes: number;
  meeting_type: MeetingType;
  location: string;
  institution_id: string;
}

const initialFormData: MeetingFormData = {
  title: '',
  description: '',
  meeting_date: '',
  meeting_time: '',
  duration_minutes: 60,
  meeting_type: 'virtual',
  location: '',
  institution_id: '',
};

export default function MeetingsPage() {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [institutions, setInstitutions] = useState<Institution[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedMeeting, setSelectedMeeting] = useState<Meeting | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [formData, setFormData] = useState<MeetingFormData>(initialFormData);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [view, setView] = useState<'calendar' | 'list'>('calendar');

  useEffect(() => {
    if (profile) loadData();
  }, [profile]);

  const loadData = async () => {
    if (!profile) return;
    try {
      setLoading(true);
      const [meetingsRes, institutionsRes] = await Promise.all([
        supabase.from('meetings').select('*, institution:institutions(*), user:profiles(*)').order('meeting_date', { ascending: true }),
        supabase.from('institutions').select('*'),
      ]);
      setMeetings(meetingsRes.data || []);
      setInstitutions(institutionsRes.data || []);
    } catch (error) {
      console.error('Error loading data:', error);
      toast({ title: 'Error', description: 'Failed to load meetings', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    try {
      const meetingDateTime = `${formData.meeting_date}T${formData.meeting_time}:00`;
      const meetingData = {
        title: formData.title,
        description: formData.description,
        meeting_date: meetingDateTime,
        duration_minutes: formData.duration_minutes,
        meeting_type: formData.meeting_type,
        location: formData.location || null,
        institution_id: formData.institution_id || null,
        user_id: profile.id,
      };
      if (editingId) {
        const { error } = await supabase.from('meetings').update(meetingData).eq('id', editingId);
        if (error) throw error;
        toast({ title: 'Success', description: 'Meeting updated successfully' });
      } else {
        const { error } = await supabase.from('meetings').insert([meetingData]);
        if (error) throw error;
        toast({ title: 'Success', description: 'Meeting created successfully' });
      }
      setDialogOpen(false);
      setFormData(initialFormData);
      setEditingId(null);
      loadData();
    } catch (error) {
      console.error('Error saving meeting:', error);
      toast({ title: 'Error', description: 'Failed to save meeting', variant: 'destructive' });
    }
  };

  const handleEdit = (meeting: Meeting) => {
    const date = new Date(meeting.meeting_date);
    setFormData({
      title: meeting.title,
      description: meeting.description || '',
      meeting_date: format(date, 'yyyy-MM-dd'),
      meeting_time: format(date, 'HH:mm'),
      duration_minutes: meeting.duration_minutes,
      meeting_type: meeting.meeting_type,
      location: meeting.location || '',
      institution_id: meeting.institution_id || '',
    });
    setEditingId(meeting.id);
    setDialogOpen(true);
  };

  const handleStatusChange = async (meetingId: string, status: MeetingStatus) => {
    try {
      const { error } = await supabase.from('meetings').update({ status }).eq('id', meetingId);
      if (error) throw error;
      toast({ title: 'Success', description: 'Meeting status updated' });
      loadData();
    } catch (error) {
      console.error('Error updating meeting:', error);
      toast({ title: 'Error', description: 'Failed to update meeting status', variant: 'destructive' });
    }
  };

  const handleDelete = async (meetingId: string) => {
    try {
      const { error } = await supabase.from('meetings').delete().eq('id', meetingId);
      if (error) throw error;
      toast({ title: 'Success', description: 'Meeting deleted' });
      setDetailOpen(false);
      loadData();
    } catch (error) {
      console.error('Error deleting meeting:', error);
      toast({ title: 'Error', description: 'Failed to delete meeting', variant: 'destructive' });
    }
  };

  const getMeetingsForDay = (date: Date) => meetings.filter((m) => isSameDay(new Date(m.meeting_date), date));

  const getMeetingTypeIcon = (type: MeetingType) => {
    if (type === 'virtual') return Video;
    if (type === 'in_person') return MapPin;
    return Phone;
  };

  const upcomingMeetings = meetings.filter((m) => new Date(m.meeting_date) >= new Date() && m.status === 'scheduled').sort((a, b) => new Date(a.meeting_date).getTime() - new Date(b.meeting_date).getTime());
  const pastMeetings = meetings.filter((m) => new Date(m.meeting_date) < new Date() || m.status !== 'scheduled').sort((a, b) => new Date(b.meeting_date).getTime() - new Date(a.meeting_date).getTime());

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
  const emptyDays = monthStart.getDay();
  const calendarDays: (Date | null)[] = [];
  for (let i = 0; i < emptyDays; i++) calendarDays.push(null);
  days.forEach(d => calendarDays.push(d));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Meetings</h2>
          <p className="text-muted-foreground">Schedule and manage your meetings</p>
        </div>
        <div className="flex gap-2">
          <Tabs value={view} onValueChange={(v) => setView(v as 'calendar' | 'list')}>
            <TabsList>
              <TabsTrigger value="calendar"><Calendar className="h-4 w-4 mr-2" />Calendar</TabsTrigger>
              <TabsTrigger value="list"><CalendarCheck className="h-4 w-4 mr-2" />List</TabsTrigger>
            </TabsList>
          </Tabs>
          <Button onClick={() => { setFormData(initialFormData); setEditingId(null); setDialogOpen(true); }}><Plus className="h-4 w-4 mr-2" />New Meeting</Button>
        </div>
      </div>

      {view === 'calendar' ? (
        <Card className="glass-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              <Button variant="outline" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>Previous</Button>
              <h3 className="text-lg font-semibold">{format(currentMonth, 'MMMM yyyy')}</h3>
              <Button variant="outline" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>Next</Button>
            </div>
            <div className="grid grid-cols-7 gap-1">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                <div key={day} className="p-2 text-center text-sm font-medium text-muted-foreground">{day}</div>
              ))}
              {calendarDays.map((day, i) => day === null ? (
                <div key={`empty-${i}`} className="min-h-[80px] p-1" />
              ) : (
                <div key={day.toISOString()} className={`min-h-[80px] p-1 rounded-lg border border-border/50 hover:bg-secondary/50 transition-colors cursor-pointer ${isToday(day) ? 'bg-primary/10 border-primary/50' : ''}`} onClick={() => { setFormData({ ...initialFormData, meeting_date: format(day, 'yyyy-MM-dd') }); setDialogOpen(true); }}>
                  <div className="text-sm font-medium mb-1">{format(day, 'd')}</div>
                  {getMeetingsForDay(day).slice(0, 2).map((m) => (
                    <div key={m.id} className="text-xs px-1 py-0.5 rounded bg-primary/20 text-primary truncate mb-0.5" onClick={(e) => { e.stopPropagation(); setSelectedMeeting(m); setDetailOpen(true); }}>{m.title}</div>
                  ))}
                  {getMeetingsForDay(day).length > 2 && <div className="text-xs text-muted-foreground pl-1">+{getMeetingsForDay(day).length - 2} more</div>}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="glass-card">
            <CardHeader><CardTitle className="flex items-center gap-2"><Clock className="h-5 w-5 text-primary" />Upcoming Meetings ({upcomingMeetings.length})</CardTitle></CardHeader>
            <CardContent>
              {loading ? <div className="space-y-4">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div> : upcomingMeetings.length === 0 ? <p className="text-muted-foreground text-center py-8">No upcoming meetings</p> : (
                <div className="space-y-3">{upcomingMeetings.map((m) => { const Icon = getMeetingTypeIcon(m.meeting_type); return (
                  <div key={m.id} className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary cursor-pointer transition-colors" onClick={() => { setSelectedMeeting(m); setDetailOpen(true); }}>
                    <div className="flex items-start justify-between"><div><p className="font-medium">{m.title}</p><p className="text-sm text-muted-foreground">{m.institution?.institution_name}</p></div><Badge className={MEETING_STATUS_COLORS[m.status]}>{m.status}</Badge></div>
                    <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground"><span className="flex items-center gap-1"><Clock className="h-3 w-3" />{format(new Date(m.meeting_date), 'MMM d, p')}</span><span className="flex items-center gap-1"><Icon className="h-3 w-3" />{m.meeting_type}</span></div>
                  </div>
                );})}</div>
              )}
            </CardContent>
          </Card>
          <Card className="glass-card">
            <CardHeader><CardTitle className="flex items-center gap-2"><CheckCircle className="h-5 w-5 text-green-500" />Past Meetings ({pastMeetings.length})</CardTitle></CardHeader>
            <CardContent>
              {loading ? <div className="space-y-4">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div> : pastMeetings.length === 0 ? <p className="text-muted-foreground text-center py-8">No past meetings</p> : (
                <div className="space-y-3">{pastMeetings.slice(0, 10).map((m) => (
                  <div key={m.id} className="p-4 rounded-lg bg-secondary/50 hover:bg-secondary cursor-pointer transition-colors" onClick={() => { setSelectedMeeting(m); setDetailOpen(true); }}>
                    <div className="flex items-start justify-between"><div><p className="font-medium">{m.title}</p><p className="text-sm text-muted-foreground">{m.institution?.institution_name}</p></div><Badge className={MEETING_STATUS_COLORS[m.status]}>{m.status}</Badge></div>
                    <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground"><span className="flex items-center gap-1"><Clock className="h-3 w-3" />{format(new Date(m.meeting_date), 'MMM d, p')}</span></div>
                  </div>
                ))}</div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editingId ? 'Edit Meeting' : 'New Meeting'}</DialogTitle><DialogDescription>{editingId ? 'Update meeting details' : 'Schedule a new meeting'}</DialogDescription></DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2"><Label>Institution</Label><Select value={formData.institution_id} onValueChange={(v) => setFormData({ ...formData, institution_id: v })}><SelectTrigger><SelectValue placeholder="Select institution (optional)" /></SelectTrigger><SelectContent>{institutions.map((i) => <SelectItem key={i.id} value={i.id}>{i.institution_name}</SelectItem>)}</SelectContent></Select></div>
            <div className="space-y-2"><Label>Title *</Label><Input value={formData.title} onChange={(e) => setFormData({ ...formData, title: e.target.value })} placeholder="e.g., Initial discovery call" required /></div>
            <div className="grid grid-cols-2 gap-4"><div className="space-y-2"><Label>Date *</Label><Input type="date" value={formData.meeting_date} onChange={(e) => setFormData({ ...formData, meeting_date: e.target.value })} required /></div><div className="space-y-2"><Label>Time *</Label><Input type="time" value={formData.meeting_time} onChange={(e) => setFormData({ ...formData, meeting_time: e.target.value })} required /></div></div>
            <div className="space-y-2"><Label>Duration (minutes)</Label><Select value={formData.duration_minutes.toString()} onValueChange={(v) => setFormData({ ...formData, duration_minutes: parseInt(v) })}><SelectTrigger /><SelectContent><SelectItem value="15">15 minutes</SelectItem><SelectItem value="30">30 minutes</SelectItem><SelectItem value="45">45 minutes</SelectItem><SelectItem value="60">1 hour</SelectItem><SelectItem value="90">1.5 hours</SelectItem><SelectItem value="120">2 hours</SelectItem></SelectContent></Select></div>
            <div className="space-y-2"><Label>Meeting Type</Label><Select value={formData.meeting_type} onValueChange={(v: MeetingType) => setFormData({ ...formData, meeting_type: v })}><SelectTrigger /><SelectContent>{MEETING_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent></Select></div>
            {formData.meeting_type === 'in_person' && <div className="space-y-2"><Label>Location *</Label><Input value={formData.location} onChange={(e) => setFormData({ ...formData, location: e.target.value })} placeholder="e.g., Conference Room A" required /></div>}
            <div className="space-y-2"><Label>Description</Label><Textarea value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} placeholder="Meeting agenda and notes..." rows={3} /></div>
            <DialogFooter><Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button><Button type="submit">{editingId ? 'Update' : 'Create'}</Button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{selectedMeeting?.title}</DialogTitle><DialogDescription>{selectedMeeting?.institution?.institution_name}</DialogDescription></DialogHeader>
          {selectedMeeting && (() => { const Icon = getMeetingTypeIcon(selectedMeeting.meeting_type); return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4"><div className="p-3 rounded-lg bg-secondary/50"><p className="text-xs text-muted-foreground mb-1">Date & Time</p><p className="font-medium flex items-center gap-2"><Clock className="h-4 w-4 text-primary" />{format(new Date(selectedMeeting.meeting_date), 'PPP p')}</p></div><div className="p-3 rounded-lg bg-secondary/50"><p className="text-xs text-muted-foreground mb-1">Duration</p><p className="font-medium">{selectedMeeting.duration_minutes} minutes</p></div></div>
            <div className="flex items-center gap-4"><Badge className={MEETING_STATUS_COLORS[selectedMeeting.status]}>{selectedMeeting.status}</Badge><div className="flex items-center gap-2 text-muted-foreground"><Icon className="h-4 w-4" /><span>{selectedMeeting.meeting_type}</span></div></div>
            {selectedMeeting.location && <div className="p-3 rounded-lg bg-secondary/50"><p className="text-xs text-muted-foreground mb-1">Location</p><p className="text-sm">{selectedMeeting.location}</p></div>}
            {selectedMeeting.description && <div className="p-3 rounded-lg bg-secondary/50"><p className="text-xs text-muted-foreground mb-1">Description</p><p className="text-sm">{selectedMeeting.description}</p></div>}
            {selectedMeeting.status === 'scheduled' && <div className="flex gap-2"><Button variant="default" onClick={() => handleStatusChange(selectedMeeting.id, 'completed')} className="flex-1"><CheckCircle className="h-4 w-4 mr-2" />Mark Complete</Button><Button variant="outline" onClick={() => handleStatusChange(selectedMeeting.id, 'cancelled')}><XCircle className="h-4 w-4" /></Button></div>}
            <div className="flex gap-2 justify-between"><Button variant="outline" onClick={() => handleEdit(selectedMeeting)}><Edit className="h-4 w-4 mr-2" />Edit</Button><Button variant="destructive" onClick={() => handleDelete(selectedMeeting.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</Button></div>
          </div>
          );})()}
        </DialogContent>
      </Dialog>
    </div>
  );
}
