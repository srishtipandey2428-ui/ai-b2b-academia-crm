import { NextRequest, NextResponse } from 'next/server';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export async function OPTIONS() {
  return NextResponse.json(null, { status: 200, headers: corsHeaders });
}

export async function POST(request: NextRequest) {
  try {
    const { lead } = await request.json();

    if (!lead) {
      return NextResponse.json(
        { error: 'Lead data is required' },
        { status: 400, headers: corsHeaders }
      );
    }

    // Generate AI insights based on lead characteristics
    const insights = analyzeLead(lead);

    return NextResponse.json(insights, { headers: corsHeaders });
  } catch (error) {
    console.error('Error analyzing lead:', error);
    return NextResponse.json(
      { error: 'Failed to analyze lead' },
      { status: 500, headers: corsHeaders }
    );
  }
}

function analyzeLead(lead: any) {
  // Calculate priority score based on various factors
  let score = 50; // Base score

  // Student strength factor
  if (lead.student_strength) {
    if (lead.student_strength > 10000) score += 20;
    else if (lead.student_strength > 5000) score += 15;
    else if (lead.student_strength > 2000) score += 10;
    else if (lead.student_strength > 500) score += 5;
  }

  // Institution type factor
  if (lead.institution_type === 'university') score += 15;
  else if (lead.institution_type === 'college') score += 10;
  else if (lead.institution_type === 'polytechnic') score += 5;

  // State factor (tier-1 cities)
  const tier1States = ['Maharashtra', 'Karnataka', 'Tamil Nadu', 'Delhi', 'Gujarat'];
  if (tier1States.includes(lead.state)) score += 10;

  // Program interest factor
  if (lead.program_interest) {
    if (lead.program_interest === 'Internship' || lead.program_interest === 'Certification Program') {
      score += 10;
    }
  }

  // Lead source factor
  if (lead.lead_source === 'Referral' || lead.lead_source === 'Event') {
    score += 8;
  }

  // Ensure score is within 0-100 range
  score = Math.min(100, Math.max(0, score));

  // Determine potential rating
  let potentialRating = 'low';
  if (score >= 85) potentialRating = 'very_high';
  else if (score >= 70) potentialRating = 'high';
  else if (score >= 50) potentialRating = 'medium';

  // Calculate partnership probability based on score
  const partnershipProbability = Math.round(score * 0.85);

  // Generate recommended action
  const recommendedAction = generateRecommendedAction(lead, score);

  // Generate insights text
  const insights = generateInsights(lead, score);

  // Generate personalized outreach message
  const outreachMessage = generateOutreachMessage(lead);

  return {
    priorityScore: score,
    potentialRating,
    partnershipProbability,
    recommendedAction,
    insights,
    outreachMessage,
  };
}

function generateRecommendedAction(lead: any, score: number): string {
  if (score >= 85) {
    return `High-priority lead! Schedule a decision-maker meeting within 2-3 days. Focus on presenting comprehensive partnership proposal with ROI metrics.`;
  } else if (score >= 70) {
    return `Schedule introductory call this week. Prepare customized demo and case studies relevant to ${lead.institution_type}s in ${lead.state}.`;
  } else if (score >= 50) {
    return `Send personalized introduction email with program brochures. Follow up with a call in 3-5 days.`;
  } else {
    return `Add to nurture campaign. Share relevant content and industry insights for 2-3 weeks before direct outreach.`;
  }
}

function generateInsights(lead: any, score: number): string {
  const strengthInfo = lead.student_strength
    ? `With ${lead.student_strength.toLocaleString()} students,`
    : 'This institution';

  const typeInfo = lead.institution_type === 'university'
    ? 'Universities typically have larger budgets and multiple department decision-makers.'
    : lead.institution_type === 'college'
    ? 'Colleges often seek industry partnerships for placement enhancement.'
    : 'Institutes usually have focused programs and quicker decision cycles.';

  return `${strengthInfo} ${lead.institution_name} presents a ${score >= 70 ? 'strong' : 'moderate'} partnership opportunity. ${typeInfo} Located in ${lead.state}, which has ${['Maharashtra', 'Karnataka', 'Tamil Nadu'].includes(lead.state) ? 'high demand for technical training' : 'growing demand for industry-academia collaboration'}. ${lead.program_interest ? `Their interest in ${lead.program_interest} programs aligns well with our offerings.` : 'Identify their specific program interests during initial contact.'}`;
}

function generateOutreachMessage(lead: any): string {
  return `Dear ${lead.contact_person || 'TPO/Principal'},

I hope this message finds you well. I wanted to reach out regarding a potential industry-academia partnership with ${lead.institution_name}.

${lead.student_strength ? `With over ${lead.student_strength.toLocaleString()} students and` : 'With'} a strong commitment to student development, I believe our ${lead.program_interest || 'training and internship'} programs could create significant value for your institution and students.

I would love to schedule a brief call to discuss how we can collaborate to enhance your students' industry readiness and career opportunities.

Looking forward to connecting with you.

Best regards,
[Your Name]
EdTech Partnership Team`;
}
