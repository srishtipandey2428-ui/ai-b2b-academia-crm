import { NextRequest, NextResponse } from 'next/server';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export async function OPTIONS() {
  return NextResponse.json(null, { status: 200, headers: corsHeaders });
}

export async function POST(request: NextRequest) {
  try {
    const { institution, emailType } = await request.json();

    if (!institution) {
      return NextResponse.json(
        { error: 'Institution data is required' },
        { status: 400, headers: corsHeaders }
      );
    }

    const email = generateEmail(institution, emailType);

    return NextResponse.json(email, { headers: corsHeaders });
  } catch (error) {
    console.error('Error generating email:', error);
    return NextResponse.json(
      { error: 'Failed to generate email' },
      { status: 500, headers: corsHeaders }
    );
  }
}

function generateEmail(institution: any, emailType: string): { subject: string; body: string } {
  const templates: Record<string, { subject: string; body: string }> = {
    introduction: {
      subject: `Industry-Academia Partnership Opportunity for ${institution.institution_name}`,
      body: `Dear ${institution.contact_person || 'TPO/Principal'},

I hope this message finds you well. I am reaching out to explore potential collaboration opportunities with ${institution.institution_name}.

About Us:
Our organization specializes in delivering industry-relevant technical training and internship programs that bridge the gap between academic curriculum and industry requirements. We have successfully partnered with 50+ institutions and trained 10,000+ students across India.

Why Partner with Us?
${institution.student_strength ? `With ${institution.student_strength.toLocaleString()} students, I believe our programs could significantly impact your institution's placement outcomes.` : 'Our tailored programs can enhance your students\' industry readiness and career prospects.'}

Key Benefits:
- Industry-recognized certifications
- Hands-on project experience with real-world scenarios
- 95% placement assistance with our 200+ hiring partners
- Continuous assessment and personalized feedback
- Faculty development programs

I would be delighted to schedule a 15-minute call to discuss how we can tailor our programs to meet ${institution.institution_name}'s specific requirements.

Looking forward to connecting with you.

Warm regards,
[Your Name]
[Your Title]
[Email] | [Phone]`,
    },
    proposal_followup: {
      subject: `Following Up - Partnership Proposal for ${institution.institution_name}`,
      body: `Dear ${institution.contact_person || 'TPO/Principal'},

I wanted to follow up on the partnership proposal we shared recently regarding collaboration opportunities with ${institution.institution_name}.

I understand that reviewing such proposals takes time, and I wanted to check if you had any questions or needed additional information.

Quick Recap of Our Offer:
- ${institution.program_interest || 'Comprehensive training programs'} for your students
- Industry-recognized certification
- Placement assistance with our hiring partners
- Flexible scheduling for your academic calendar

${institution.priority_score && institution.priority_score >= 70 ?
  `Given ${institution.institution_name}'s impressive track record and ${institution.student_strength?.toLocaleString() || 'strong'} student base, I'm confident this partnership would yield excellent results for both our organizations.` :
  `I'm confident that a collaboration would add significant value to ${institution.institution_name}'s training initiatives.`}

Would you be available for a brief call this week to discuss next steps?

Best regards,
[Your Name]`,
    },
    meeting_reminder: {
      subject: `Reminder: Upcoming Meeting with ${institution.institution_name}`,
      body: `Dear ${institution.contact_person || 'TPO/Principal'},

This is a friendly reminder about our upcoming meeting to discuss partnership opportunities with ${institution.institution_name}.

Meeting Details:
Date: [Date]
Time: [Time]
Duration: 30 minutes
Platform: Google Meet / Zoom
Link: [Meeting Link]

Agenda:
1. Introduction and understanding your current training programs
2. Our collaboration model and success stories
3. Customization options for ${institution.institution_name}
4. Q&A and next steps

Please let me know if you need to reschedule or have any questions before the meeting.

Looking forward to our conversation!

Best regards,
[Your Name]`,
    },
    partnership_proposal: {
      subject: `Partnership Proposal - Tailored for ${institution.institution_name}`,
      body: `Dear ${institution.contact_person || 'TPO/Principal'},

Thank you for your interest in exploring a partnership. I'm pleased to share a comprehensive proposal tailored specifically for ${institution.institution_name}.

PROPOSAL SUMMARY:

Institution: ${institution.institution_name}
Location: ${institution.city}, ${institution.state}
${institution.student_strength ? `Expected Student Reach: ${institution.student_strength.toLocaleString()}` : ''}

PROGRAM OPTIONS:
1. ${institution.program_interest || 'Technical Training'} - Industry-relevant modules
2. Internship Program - 4-6 weeks hands-on experience
3. Certification Course - Industry-recognized credentials

KEY BENEFITS FOR ${institution.institution_name.toUpperCase()}:
✓ Enhanced placement rates with our 200+ hiring partners
✓ Industry-ready curriculum with hands-on projects
✓ Faculty development and training
✓ Real-time assessment and progress tracking
✓ Dedicated support team for seamless implementation

INVESTMENT:
Our engagement model is flexible and can be customized based on your requirements and student strength.

NEXT STEPS:
1. Review this proposal
2. Schedule a discussion to address any questions
3. Finalize program details and timeline
4. Sign the Memorandum of Understanding

I'm available for a call at your convenience to walk through the details.

Best regards,
[Your Name]
[Contact Information]`,
    },
    custom: {
      subject: `Regarding Partnership with ${institution.institution_name}`,
      body: `Dear ${institution.contact_person || 'TPO/Principal'},

I'm reaching out regarding ${institution.institution_name}.

[Your message here]

Best regards,
[Your Name]`,
    },
  };

  return templates[emailType] || templates.custom;
}
